// AI4COLAB Session Switcher & Cookie Editor — Background Service Worker
// Features: Auto-Save, Multi-Account Session Manager, Per-Tab Cookie Isolation Engine (DNR MV3),
// Remote Kill Switch, and Live GitHub Update Checker.

const CURRENT_VERSION = '27.8.2026.8.15';
const CURRENT_VERSION_CODE = '27.8.2026.815';
const DEFAULT_CONFIG_URL = 'https://raw.githubusercontent.com/wwwrajdev/webcookies/main/config.json';

let saveTimeouts = {};

// -------------------------------------------------------------
// 0. Remote GitHub Config, Kill Switch & Update Checker Engine
// -------------------------------------------------------------

async function getRemoteConfigUrl() {
  return new Promise((resolve) => {
    chrome.storage.local.get('remote_config_url', (res) => {
      resolve(res.remote_config_url || DEFAULT_CONFIG_URL);
    });
  });
}

async function fetchRemoteConfig(customUrl = null) {
  const url = customUrl || (await getRemoteConfigUrl());
  try {
    const cacheBuster = `${url.includes('?') ? '&' : '?'}_t=${Date.now()}`;
    const response = await fetch(url + cacheBuster, {
      method: 'GET',
      headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache' }
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const config = await response.json();
    const isKillSwitched = config.kill_switch === true || config.status === 'disabled';

    // Compare versions
    const updateAvailable = config.update_available === true || (config.latest_version && isNewerVersion(config.latest_version, CURRENT_VERSION));

    const state = {
      config: config,
      kill_switch_active: isKillSwitched,
      kill_switch_message: config.kill_switch_message || 'Extension is currently disabled by administrator.',
      update_available: updateAvailable,
      latest_version: config.latest_version || CURRENT_VERSION,
      last_checked_at: Date.now(),
      status: isKillSwitched ? 'disabled' : (config.status || 'active'),
      url: url
    };

    await chrome.storage.local.set({ 'remote_config_state': state });
    return { success: true, state: state };
  } catch (err) {
    console.warn('AI4COLAB: Could not reach remote GitHub config:', err.message);

    // Fall back to existing cached state if available
    const existing = await new Promise((res) => {
      chrome.storage.local.get('remote_config_state', (r) => res(r.remote_config_state || null));
    });

    if (existing) {
      return { success: false, error: err.message, state: existing, isFallback: true };
    }

    // Default safe fallback
    const defaultState = {
      config: { status: 'active', kill_switch: false },
      kill_switch_active: false,
      kill_switch_message: '',
      update_available: false,
      latest_version: CURRENT_VERSION,
      last_checked_at: Date.now(),
      status: 'active',
      url: url
    };
    return { success: false, error: err.message, state: defaultState };
  }
}

// Compare semantic or timestamp version strings
function isNewerVersion(remote, local) {
  if (!remote || !local) return false;
  if (remote === local) return false;

  const rParts = remote.split('.').map(n => parseInt(n, 10) || 0);
  const lParts = local.split('.').map(n => parseInt(n, 10) || 0);
  const maxLen = Math.max(rParts.length, lParts.length);

  for (let i = 0; i < maxLen; i++) {
    const r = rParts[i] || 0;
    const l = lParts[i] || 0;
    if (r > l) return true;
    if (r < l) return false;
  }
  return false;
}

// Periodic check via Chrome Alarms (every 30 mins)
if (chrome.alarms) {
  chrome.alarms.create('check_remote_config_alarm', { periodInMinutes: 30 });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'check_remote_config_alarm') {
      fetchRemoteConfig();
    }
  });
}

// Initial check on startup
fetchRemoteConfig();

// -------------------------------------------------------------
// 1. Per-Tab Cookie Isolation State & DeclarativeNetRequest Engine
// -------------------------------------------------------------

async function getIsolatedTabsRegistry() {
  return new Promise((resolve) => {
    chrome.storage.local.get('isolated_tabs', (res) => {
      resolve(res.isolated_tabs || {});
    });
  });
}

async function saveIsolatedTabsRegistry(registry) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ 'isolated_tabs': registry }, resolve);
  });
}

// Build standard HTTP Cookie header string from array of cookie objects
function buildCookieHeaderValue(cookies) {
  if (!cookies || !Array.isArray(cookies) || cookies.length === 0) return '';

  const map = new Map();
  cookies.forEach(c => {
    if (c && c.name && c.value !== undefined) {
      map.set(c.name, c.value);
    }
  });

  const pairs = [];
  map.forEach((val, key) => {
    pairs.push(`${key}=${val}`);
  });

  return pairs.join('; ');
}

// Update declarativeNetRequest dynamic session rules for a specific tab
async function updateTabDnrRule(tabId, domain, cookies) {
  if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateSessionRules) {
    return;
  }

  const ruleId = Math.abs(Number(tabId));
  if (!ruleId) return;

  const cookieHeaderValue = buildCookieHeaderValue(cookies);

  // Remove existing rule for this tab first
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [ruleId]
    });
  } catch (e) { }

  const allResourceTypes = [
    'main_frame',
    'sub_frame',
    'stylesheet',
    'script',
    'image',
    'font',
    'object',
    'xmlhttprequest',
    'ping',
    'media',
    'websocket',
    'other'
  ];

  if (!cookieHeaderValue) {
    try {
      await chrome.declarativeNetRequest.updateSessionRules({
        addRules: [
          {
            id: ruleId,
            priority: 100,
            action: {
              type: 'modifyHeaders',
              requestHeaders: [
                {
                  header: 'Cookie',
                  operation: 'set',
                  value: ''
                }
              ]
            },
            condition: {
              tabIds: [tabId],
              resourceTypes: allResourceTypes
            }
          }
        ]
      });
    } catch (e) {
      console.warn('AI4COLAB: Failed to apply empty isolation rule for tab', tabId, e);
    }
    return;
  }

  // Create modifyHeaders rule targeting only this specific tabId
  const newRule = {
    id: ruleId,
    priority: 100,
    action: {
      type: 'modifyHeaders',
      requestHeaders: [
        {
          header: 'Cookie',
          operation: 'set',
          value: cookieHeaderValue
        }
      ]
    },
    condition: {
      tabIds: [tabId],
      resourceTypes: allResourceTypes
    }
  };

  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      addRules: [newRule]
    });
  } catch (err) {
    console.error('AI4COLAB: Error updating DNR session rule for tab', tabId, err);
  }
}

// Remove isolation rule and registry entry for a tab
async function removeTabIsolation(tabId) {
  const ruleId = Math.abs(Number(tabId));
  if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateSessionRules) {
    try {
      await chrome.declarativeNetRequest.updateSessionRules({
        removeRuleIds: [ruleId]
      });
    } catch (e) { }
  }

  const registry = await getIsolatedTabsRegistry();
  if (registry[tabId]) {
    delete registry[tabId];
    await saveIsolatedTabsRegistry(registry);
  }
}

// Clean up rules when tabs close
chrome.tabs.onRemoved.addListener((tabId) => {
  removeTabIsolation(tabId);
});

// Restore DNR rules on extension startup or service worker wake up
async function restoreAllActiveIsolatedRules() {
  const registry = await getIsolatedTabsRegistry();
  const tabIds = Object.keys(registry);

  for (const tabIdStr of tabIds) {
    const tabId = parseInt(tabIdStr, 10);
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab) {
        const item = registry[tabIdStr];
        await updateTabDnrRule(tabId, item.domain, item.cookies);
      } else {
        delete registry[tabIdStr];
      }
    } catch (e) {
      delete registry[tabIdStr];
    }
  }
  await saveIsolatedTabsRegistry(registry);
}

restoreAllActiveIsolatedRules();

// -------------------------------------------------------------
// 2. Messaging Handler for Popup, Dashboard & Content Scripts
// -------------------------------------------------------------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  const senderTabId = sender.tab ? sender.tab.id : null;

  // Remote Config: Check now
  if (message.type === 'CHECK_REMOTE_CONFIG') {
    fetchRemoteConfig(message.url).then(res => sendResponse(res));
    return true;
  }

  // Remote Config: Get cached state
  if (message.type === 'GET_REMOTE_CONFIG_STATUS') {
    chrome.storage.local.get('remote_config_state', (res) => {
      const state = res.remote_config_state || {
        kill_switch_active: false,
        update_available: false,
        latest_version: CURRENT_VERSION,
        status: 'active'
      };
      sendResponse({ success: true, state: state, current_version: CURRENT_VERSION });
    });
    return true;
  }

  // Remote Config: Set custom GitHub JSON URL
  if (message.type === 'SET_REMOTE_CONFIG_URL') {
    const newUrl = message.url || DEFAULT_CONFIG_URL;
    chrome.storage.local.set({ 'remote_config_url': newUrl }, () => {
      fetchRemoteConfig(newUrl).then(res => sendResponse(res));
    });
    return true;
  }

  // Handler: Get Isolation info for current tab
  if (message.type === 'GET_TAB_ISOLATION_INFO') {
    const targetTabId = message.tabId || senderTabId;
    getIsolatedTabsRegistry().then((registry) => {
      const info = registry[targetTabId] || null;
      sendResponse({ success: true, isIsolated: !!info, data: info });
    });
    return true;
  }

  // Handler: Get all active isolated tabs
  if (message.type === 'GET_ALL_ISOLATED_TABS') {
    getIsolatedTabsRegistry().then((registry) => {
      sendResponse({ success: true, registry: registry });
    });
    return true;
  }

  // Handler: Open a new isolated tab for a domain/profile with 100% cookie reliability
  if (message.type === 'OPEN_ISOLATED_TAB') {
    const domain = message.domain || '';
    const profile = message.profile || { name: 'Isolated Session', cookies: [] };
    const rawUrl = message.url || (domain ? (domain.startsWith('http') ? domain : `https://${domain}`) : 'about:blank');

    // 1. Create tab at about:blank first so NO network request is dispatched before DNR rule is ready
    chrome.tabs.create({ url: 'about:blank', active: true }, async (newTab) => {
      const tabId = newTab.id;

      let cleanDomain = domain;
      if (!cleanDomain && rawUrl && !rawUrl.startsWith('about:')) {
        try { cleanDomain = new URL(rawUrl).hostname; } catch (e) { }
      }
      if (cleanDomain.startsWith('http')) {
        try { cleanDomain = new URL(cleanDomain).hostname; } catch (e) { }
      }

      const cookiesList = profile.cookies ? JSON.parse(JSON.stringify(profile.cookies)) : [];

      const isolatedItem = {
        tabId: tabId,
        domain: cleanDomain,
        profileId: profile.id || `iso-profile-${Date.now()}`,
        profileName: profile.name || 'Isolated Session',
        isolatedAt: Date.now(),
        cookies: cookiesList
      };

      // 2. Save into registry
      const registry = await getIsolatedTabsRegistry();
      registry[tabId] = isolatedItem;
      await saveIsolatedTabsRegistry(registry);

      // 3. Register DNR rule BEFORE navigating the tab
      await updateTabDnrRule(tabId, cleanDomain, cookiesList);

      // 4. Navigate tab to target URL! The initial HTTP request will carry the isolated cookies header!
      chrome.tabs.update(tabId, { url: rawUrl }, () => {
        sendResponse({ success: true, tab: newTab, isolatedItem: isolatedItem });
      });
    });
    return true;
  }

  // Handler: Isolate an existing open tab
  if (message.type === 'ISOLATE_EXISTING_TAB') {
    const tabId = message.tabId;
    const domain = message.domain;
    const profile = message.profile || { name: 'Isolated Tab', cookies: [] };

    (async () => {
      const cleanDomain = domain ? (domain.startsWith('http') ? new URL(domain).hostname : domain) : '';
      const cookiesList = profile.cookies ? JSON.parse(JSON.stringify(profile.cookies)) : [];

      const isolatedItem = {
        tabId: tabId,
        domain: cleanDomain,
        profileId: profile.id || `iso-profile-${Date.now()}`,
        profileName: profile.name || 'Isolated Session',
        isolatedAt: Date.now(),
        cookies: cookiesList
      };

      const registry = await getIsolatedTabsRegistry();
      registry[tabId] = isolatedItem;
      await saveIsolatedTabsRegistry(registry);
      await updateTabDnrRule(tabId, cleanDomain, cookiesList);

      chrome.tabs.reload(tabId, {}, () => {
        sendResponse({ success: true, isolatedItem: isolatedItem });
      });
    })();
    return true;
  }

  // Handler: Set/Add a cookie in an isolated tab
  if (message.type === 'SET_ISOLATED_COOKIE') {
    const tabId = message.tabId;
    const cookieObj = message.cookie;

    (async () => {
      const registry = await getIsolatedTabsRegistry();
      if (!registry[tabId]) {
        sendResponse({ success: false, error: 'Tab is not isolated' });
        return;
      }

      const cookies = registry[tabId].cookies || [];
      const idx = cookies.findIndex(c => c.name === cookieObj.name);
      if (idx !== -1) {
        cookies[idx] = Object.assign({}, cookies[idx], cookieObj);
      } else {
        cookies.push(cookieObj);
      }

      registry[tabId].cookies = cookies;
      await saveIsolatedTabsRegistry(registry);
      await updateTabDnrRule(tabId, registry[tabId].domain, cookies);

      sendResponse({ success: true, cookies: cookies });
    })();
    return true;
  }

  // Handler: Delete a cookie from an isolated tab
  if (message.type === 'DELETE_ISOLATED_COOKIE') {
    const tabId = message.tabId;
    const cookieName = message.cookieName;

    (async () => {
      const registry = await getIsolatedTabsRegistry();
      if (!registry[tabId]) {
        sendResponse({ success: false, error: 'Tab is not isolated' });
        return;
      }

      let cookies = registry[tabId].cookies || [];
      cookies = cookies.filter(c => c.name !== cookieName);
      registry[tabId].cookies = cookies;

      await saveIsolatedTabsRegistry(registry);
      await updateTabDnrRule(tabId, registry[tabId].domain, cookies);

      sendResponse({ success: true, cookies: cookies });
    })();
    return true;
  }

  // Handler: Delete all cookies in an isolated tab
  if (message.type === 'CLEAR_ISOLATED_COOKIES') {
    const tabId = message.tabId;

    (async () => {
      const registry = await getIsolatedTabsRegistry();
      if (!registry[tabId]) {
        sendResponse({ success: false, error: 'Tab is not isolated' });
        return;
      }

      registry[tabId].cookies = [];
      await saveIsolatedTabsRegistry(registry);
      await updateTabDnrRule(tabId, registry[tabId].domain, []);

      sendResponse({ success: true });
    })();
    return true;
  }

  // Handler: Cookie mutation reported from content script inside an isolated tab
  if (message.type === 'REPORT_ISOLATED_COOKIE_MUTATION' && senderTabId) {
    (async () => {
      const registry = await getIsolatedTabsRegistry();
      if (!registry[senderTabId]) return;

      const cookies = registry[senderTabId].cookies || [];
      const { name, value, isExpired } = message;

      if (isExpired) {
        registry[senderTabId].cookies = cookies.filter(c => c.name !== name);
      } else {
        const existingIdx = cookies.findIndex(c => c.name === name);
        if (existingIdx !== -1) {
          cookies[existingIdx].value = value;
        } else {
          cookies.push({
            name: name,
            value: value,
            domain: registry[senderTabId].domain || '',
            path: '/',
            secure: true,
            httpOnly: false
          });
        }
        registry[senderTabId].cookies = cookies;
      }

      await saveIsolatedTabsRegistry(registry);
      await updateTabDnrRule(senderTabId, registry[senderTabId].domain, registry[senderTabId].cookies);
      sendResponse({ success: true });
    })();
    return true;
  }

  // Handler: Detach / End isolation for a tab
  if (message.type === 'END_TAB_ISOLATION') {
    const tabId = message.tabId;
    removeTabIsolation(tabId).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  // Handler: Open Chrome/Edge Side Panel
  if (message.type === 'OPEN_SIDE_PANEL') {
    if (chrome.sidePanel && chrome.sidePanel.open) {
      const openOpts = message.windowId ? { windowId: message.windowId } : (message.tabId ? { tabId: message.tabId } : {});
      chrome.sidePanel.open(openOpts).then(() => {
        sendResponse({ success: true });
      }).catch((err) => {
        console.warn('SidePanel open failed:', err);
        sendResponse({ success: false, error: err.message });
      });
    } else {
      sendResponse({ success: false, error: 'SidePanel API not available' });
    }
    return true;
  }
});

// Context Menus support for Side Panel
chrome.runtime.onInstalled.addListener(() => {
  if (chrome.contextMenus) {
    chrome.contextMenus.create({
      id: 'ai4colab_open_sidepanel',
      title: '📌 Open AI4COLAB Side Panel',
      contexts: ['all']
    }, () => {
      if (chrome.runtime.lastError) { }
    });
  }
});

if (chrome.contextMenus && chrome.contextMenus.onClicked) {
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'ai4colab_open_sidepanel' && tab) {
      if (chrome.sidePanel && chrome.sidePanel.open) {
        chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {
          chrome.sidePanel.open({ tabId: tab.id });
        });
      }
    }
  });
}

// -------------------------------------------------------------
// 3. Auto-Save Domain Cookies Feature (for standard browser tabs)
// -------------------------------------------------------------

chrome.cookies.onChanged.addListener((changeInfo) => {
  chrome.storage.local.get(['auto_save_enabled', 'remote_config_state'], (result) => {
    // If kill switch active or auto-save disabled, don't execute
    if (!result.auto_save_enabled) return;
    if (result.remote_config_state && result.remote_config_state.kill_switch_active) return;

    const cookie = changeInfo.cookie;
    const domain = cookie.domain;
    const cleanDomain = domain.startsWith('.') ? domain.substring(1) : domain;

    if (cleanDomain.startsWith('chrome') || cleanDomain.includes('localhost') || cleanDomain.includes('127.0.0.1')) {
      return;
    }

    if (saveTimeouts[cleanDomain]) {
      clearTimeout(saveTimeouts[cleanDomain]);
    }

    saveTimeouts[cleanDomain] = setTimeout(() => {
      autoSaveDomainCookies(cleanDomain);
      delete saveTimeouts[cleanDomain];
    }, 2000);
  });
});

function autoSaveDomainCookies(domain) {
  chrome.cookies.getAll({ domain: domain }, (cookies) => {
    if (chrome.runtime.lastError || !cookies || cookies.length === 0) return;

    const validCookies = cookies.filter(c => c.name && c.value !== undefined);
    if (validCookies.length === 0) return;

    chrome.storage.local.get('sessions_by_domain', (result) => {
      const store = result.sessions_by_domain || {};
      const domainProfiles = store[domain] || [];
      const autoIndex = domainProfiles.findIndex(p => p.id === 'profile-autosaved');

      const updatedProfile = {
        id: 'profile-autosaved',
        name: 'Auto-Saved Session',
        savedAt: Date.now(),
        cookies: validCookies
      };

      if (autoIndex !== -1) {
        domainProfiles[autoIndex] = updatedProfile;
      } else {
        domainProfiles.unshift(updatedProfile);
      }

      store[domain] = domainProfiles;
      chrome.storage.local.set({ 'sessions_by_domain': store });
    });
  });
}
