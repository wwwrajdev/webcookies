(() => {
  // Prevent double injection
  if (window.ai4colabInjected) return;
  window.ai4colabInjected = true;

  // Variables
  let isWidgetActive = false;
  let layoutMode = 'popup'; // 'popup' or 'sidepanel'
  let iframeLoaded = false;
  let tabIsolationInfo = null;

  // -------------------------------------------------------------
  // 1. Check Tab Isolation & Initialize Sandbox Bridge
  // -------------------------------------------------------------
  try {
    chrome.runtime.sendMessage({ type: 'GET_TAB_ISOLATION_INFO' }, (response) => {
      if (chrome.runtime.lastError || !response || !response.isIsolated) return;

      tabIsolationInfo = response.data;
      window.__ai4colab_isolated_active__ = true;

      // Inject the sandboxing bridge into MAIN world
      injectBridgeScript();

      // Send isolated cookies seed to the bridge
      window.postMessage({
        type: 'AI4COLAB_INIT_ISOLATED_COOKIES',
        cookies: tabIsolationInfo.cookies || []
      }, '*');

      // Create floating isolation pill on page
      createIsolationPill(tabIsolationInfo);
    });
  } catch (e) {
    // Context invalidated or internal page
  }

  // Inject isolated-bridge.js into DOM
  function injectBridgeScript() {
    try {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('isolated-bridge.js');
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
    } catch (e) {
      console.debug('AI4COLAB: could not inject bridge script', e);
    }
  }

  // Listen to mutations from bridge in page
  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || event.data.type !== 'AI4COLAB_COOKIE_MUTATED') return;
    
    try {
      chrome.runtime.sendMessage({
        type: 'REPORT_ISOLATED_COOKIE_MUTATION',
        cookieString: event.data.cookieString,
        name: event.data.name,
        value: event.data.value,
        isExpired: event.data.isExpired
      });
    } catch (e) {}
  });

  // Create In-Page Floating Isolation Indicator Pill
  function createIsolationPill(info) {
    const pill = document.createElement('div');
    pill.className = 'ai4colab-reset ai4colab-isolation-pill';
    pill.innerHTML = `
      <div class="ai4colab-pill-icon">🛡️</div>
      <div class="ai4colab-pill-text">
        <span class="ai4colab-pill-title">Isolated Tab</span>
        <span class="ai4colab-pill-name">${escapeHtml(info.profileName || 'Custom Profile')}</span>
      </div>
      <button class="ai4colab-pill-close" title="Dismiss Indicator">✕</button>
    `;

    document.body.appendChild(pill);

    pill.querySelector('.ai4colab-pill-close').addEventListener('click', (e) => {
      e.stopPropagation();
      pill.remove();
    });

    pill.addEventListener('click', () => {
      toggleWidget();
    });
  }

  // -------------------------------------------------------------
  // 2. Floating Action Button (FAB) & In-Page Extension Widget
  // -------------------------------------------------------------
  const fab = document.createElement('div');
  fab.className = 'ai4colab-reset ai4colab-fab';
  fab.title = 'AI4COLAB Session Switcher';
  
  // Embedded brand SVG matching the rules
  fab.innerHTML = `
    <svg width="26" height="26" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="ng_content_svg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#4285F4" />
          <stop offset="50%" style="stop-color:#34A853" />
          <stop offset="100%" style="stop-color:#EA4335" />
        </linearGradient>
      </defs>
      <circle cx="25" cy="25" r="23" fill="none" stroke="url(#ng_content_svg)" stroke-width="3" />
      <circle cx="25" cy="15" r="3.5" fill="#4285F4" />
      <circle cx="35" cy="25" r="3.5" fill="#34A853" />
      <circle cx="25" cy="35" r="3.5" fill="#EA4335" />
      <circle cx="15" cy="25" r="3.5" fill="#FBBC05" />
      <line x1="25" y1="15" x2="35" y2="25" stroke="#4285F4" stroke-width="2" opacity=".6" />
      <line x1="35" y1="25" x2="25" y2="35" stroke="#34A853" stroke-width="2" opacity=".6" />
      <line x1="25" y1="35" x2="15" y2="25" stroke="#EA4335" stroke-width="2" opacity=".6" />
      <line x1="15" y1="25" x2="25" y2="15" stroke="#FBBC05" stroke-width="2" opacity=".6" />
    </svg>
  `;

  // Create the Iframe Extension Widget Container
  const container = document.createElement('div');
  container.className = 'ai4colab-reset ai4colab-container ai4colab-mode-popup';
  
  container.innerHTML = `
    <div class="ai4colab-header ai4colab-drag-handle">
      <div class="ai4colab-title-box">
        <svg width="16" height="16" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg" style="vertical-align:middle;">
          <defs>
            <linearGradient id="ng_content_mini" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style="stop-color:#4285F4" />
              <stop offset="50%" style="stop-color:#34A853" />
              <stop offset="100%" style="stop-color:#EA4335" />
            </linearGradient>
          </defs>
          <circle cx="25" cy="25" r="23" fill="none" stroke="url(#ng_content_mini)" stroke-width="3" />
          <circle cx="25" cy="15" r="3.5" fill="#4285F4" />
          <circle cx="35" cy="25" r="3.5" fill="#34A853" />
          <circle cx="25" cy="35" r="3.5" fill="#EA4335" />
          <circle cx="15" cy="25" r="3.5" fill="#FBBC05" />
        </svg>
        <span class="ai4colab-title-text">AI4COLAB Switcher</span>
      </div>
      <div class="ai4colab-controls">
        <button class="ai4colab-btn ai4colab-btn-toggle" title="Toggle Layout (Popup / Side Panel)">🔀</button>
        <button class="ai4colab-btn ai4colab-btn-close" title="Close Widget">✕</button>
      </div>
    </div>
    <iframe class="ai4colab-iframe"></iframe>
  `;

  const header = container.querySelector('.ai4colab-header');
  const iframe = container.querySelector('.ai4colab-iframe');
  const btnToggle = container.querySelector('.ai4colab-btn-toggle');
  const btnClose = container.querySelector('.ai4colab-btn-close');

  // Inject elements to body when DOM is ready
  function initInjections() {
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', initInjections);
      return;
    }
    document.body.appendChild(fab);
    document.body.appendChild(container);
  }
  initInjections();

  // Click Listeners
  fab.addEventListener('click', toggleWidget);
  btnClose.addEventListener('click', hideWidget);
  btnToggle.addEventListener('click', toggleLayout);

  function toggleWidget() {
    isWidgetActive = !isWidgetActive;
    if (isWidgetActive) {
      showWidget();
    } else {
      hideWidget();
    }
  }

  function showWidget() {
    isWidgetActive = true;
    if (!iframeLoaded) {
      iframe.src = chrome.runtime.getURL('popup.html?embed=true');
      iframeLoaded = true;
    }
    container.classList.add('ai4colab-active');
  }

  function hideWidget() {
    isWidgetActive = false;
    container.classList.remove('ai4colab-active');
  }

  function toggleLayout() {
    if (layoutMode === 'popup') {
      layoutMode = 'sidepanel';
      container.classList.remove('ai4colab-mode-popup');
      container.classList.add('ai4colab-mode-sidepanel');
      header.classList.remove('ai4colab-drag-handle');
      
      container.style.top = '';
      container.style.left = '';
      container.style.bottom = '';
      container.style.right = '';
      container.style.width = '';
      container.style.height = '';
    } else {
      layoutMode = 'popup';
      container.classList.remove('ai4colab-mode-sidepanel');
      container.classList.add('ai4colab-mode-popup');
      header.classList.add('ai4colab-drag-handle');
      
      container.style.top = '';
      container.style.left = '';
      container.style.bottom = '';
      container.style.right = '';
    }
  }

  // Drag & drop logic
  let isDragging = false;
  let startX = 0, startY = 0;
  let elementStartX = 0, elementStartY = 0;

  header.addEventListener('mousedown', (e) => {
    if (layoutMode !== 'popup') return;
    if (e.target.closest('.ai4colab-btn')) return;

    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;

    const rect = container.getBoundingClientRect();
    elementStartX = rect.left;
    elementStartY = rect.top;

    document.addEventListener('mousemove', dragMove);
    document.addEventListener('mouseup', stopDrag);
    e.preventDefault();
  });

  function dragMove(e) {
    if (!isDragging) return;

    const deltaX = e.clientX - startX;
    const deltaY = e.clientY - startY;

    let newLeft = elementStartX + deltaX;
    let newTop = elementStartY + deltaY;

    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const widgetWidth = container.offsetWidth;
    const widgetHeight = container.offsetHeight;

    if (newLeft < 0) newLeft = 0;
    if (newLeft + widgetWidth > viewportWidth) newLeft = viewportWidth - widgetWidth;
    if (newTop < 0) newTop = 0;
    if (newTop + widgetHeight > viewportHeight) newTop = viewportHeight - widgetHeight;

    container.style.left = `${newLeft}px`;
    container.style.top = `${newTop}px`;
    container.style.right = 'auto';
    container.style.bottom = 'auto';
  }

  function stopDrag() {
    isDragging = false;
    document.removeEventListener('mousemove', dragMove);
    document.removeEventListener('mouseup', stopDrag);
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str.toString()
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
})();
