// AI4COLAB Isolated Tab Cookie Sandboxing Bridge (MAIN World)
(() => {
  if (window.__ai4colab_bridge_injected__) return;
  window.__ai4colab_bridge_injected__ = true;

  // Internal cookie map for this isolated tab
  const isolatedCookies = new Map();

  // Listen to initial cookie seed from content script
  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || event.data.type !== 'AI4COLAB_INIT_ISOLATED_COOKIES') return;
    
    const cookiesList = event.data.cookies || [];
    isolatedCookies.clear();
    cookiesList.forEach(c => {
      // Don't expose httpOnly cookies to document.cookie in JS, but retain others
      if (!c.httpOnly && c.name) {
        isolatedCookies.set(c.name, c.value || '');
      }
    });
  });

  // Store native document.cookie descriptor if exists
  const originalDescriptor = Object.getOwnPropertyDescriptor(Document.prototype, 'cookie') ||
                             Object.getOwnPropertyDescriptor(HTMLDocument.prototype, 'cookie');

  // Override document.cookie getter and setter
  try {
    Object.defineProperty(document, 'cookie', {
      configurable: true,
      enumerable: true,
      get: function() {
        if (!window.__ai4colab_isolated_active__) {
          return originalDescriptor && originalDescriptor.get ? originalDescriptor.get.call(document) : '';
        }
        const pairs = [];
        isolatedCookies.forEach((value, name) => {
          pairs.push(`${name}=${value}`);
        });
        return pairs.join('; ');
      },
      set: function(cookieStr) {
        if (!cookieStr || typeof cookieStr !== 'string') return;
        
        if (!window.__ai4colab_isolated_active__) {
          if (originalDescriptor && originalDescriptor.set) {
            originalDescriptor.set.call(document, cookieStr);
          }
          return;
        }

        // Parse cookie string
        const parts = cookieStr.split(';').map(s => s.trim());
        if (parts.length === 0) return;
        
        const firstPart = parts[0];
        const eqIdx = firstPart.indexOf('=');
        if (eqIdx === -1) return;
        
        const name = firstPart.substring(0, eqIdx).trim();
        const value = firstPart.substring(eqIdx + 1).trim();

        // Check for max-age=0 or expires in past (deletion)
        let isExpired = false;
        parts.slice(1).forEach(attr => {
          const lower = attr.toLowerCase();
          if (lower.startsWith('max-age=0') || lower.startsWith('max-age=-')) {
            isExpired = true;
          } else if (lower.startsWith('expires=')) {
            const expVal = attr.substring(8).trim();
            const expDate = new Date(expVal);
            if (!isNaN(expDate.getTime()) && expDate.getTime() < Date.now()) {
              isExpired = true;
            }
          }
        });

        if (isExpired) {
          isolatedCookies.delete(name);
        } else {
          isolatedCookies.set(name, value);
        }

        // Notify content script about mutation
        window.postMessage({
          type: 'AI4COLAB_COOKIE_MUTATED',
          cookieString: cookieStr,
          name: name,
          value: value,
          isExpired: isExpired
        }, '*');
      }
    });
  } catch (e) {
    console.debug('AI4COLAB: Cookie sandboxing bridge hooked.', e);
  }
})();
