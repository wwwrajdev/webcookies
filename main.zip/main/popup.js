document.addEventListener('DOMContentLoaded', async () => {
  let currentTab = null;
  let activeDomain = '';
  let activeUrl = '';
  let allCookies = [];
  let currentTabIsolation = null; // null if tab is standard, object if isolated

  // DOM Elements
  const domainTitle = document.getElementById('domain-title');
  const searchInput = document.getElementById('search-input');
  const cookieList = document.getElementById('cookie-list');
  const noCookiesMessage = document.getElementById('no-cookies');
  const isolationBanner = document.getElementById('isolation-banner');
  const isolationBannerProfile = document.getElementById('isolation-banner-profile');
  const detachIsolationBtn = document.getElementById('detach-isolation-btn');
  const cookiesModeBadge = document.getElementById('cookies-mode-badge');

  // Overlay & Form Elements
  const formOverlay = document.getElementById('cookie-form-overlay');
  const cookieForm = document.getElementById('cookie-form');
  const formTitle = document.getElementById('form-title');
  const cookieNameInput = document.getElementById('cookie-name');
  const cookieValueInput = document.getElementById('cookie-value');
  const cookieDomainInput = document.getElementById('cookie-domain');
  const cookiePathInput = document.getElementById('cookie-path');
  const cookieExpirationInput = document.getElementById('cookie-expiration');
  const cookieSameSiteInput = document.getElementById('cookie-samesite');
  const cookieHttpOnlyInput = document.getElementById('cookie-httponly');
  const cookieSecureInput = document.getElementById('cookie-secure');
  const cookieSessionInput = document.getElementById('cookie-session');

  // Action Buttons
  const addBtn = document.getElementById('add-btn');
  const deleteAllBtn = document.getElementById('delete-all-btn');
  const cancelBtn = document.getElementById('cancel-btn');
  const footerActions = document.getElementById('footer-actions');

  // JSON Action Buttons & Overlay
  const importBtn = document.getElementById('import-btn');
  const exportBtn = document.getElementById('export-btn');
  const copyBtn = document.getElementById('copy-btn');
  const importOverlay = document.getElementById('import-overlay');
  const importJsonData = document.getElementById('import-json-data');
  const importCancelBtn = document.getElementById('import-cancel-btn');
  const importSubmitBtn = document.getElementById('import-submit-btn');

  // Tab Elements (1st Sessions - DEFAULT ACTIVE, 2nd Cookies)
  const tabAccountsBtn = document.getElementById('tab-accounts');
  const tabCookiesBtn = document.getElementById('tab-cookies');
  const panelAccounts = document.getElementById('panel-accounts');
  const panelCookies = document.getElementById('panel-cookies');

  // Accounts Tab Elements
  const newProfileNameInput = document.getElementById('new-profile-name');
  const saveSessionBtn = document.getElementById('save-session-btn');
  const createCleanIsolatedBtn = document.getElementById('create-clean-isolated-btn');
  const popupAutosaveToggle = document.getElementById('popup-autosave-toggle');

  // Initialize
  await init();

  async function init() {
    // 1. Get current active tab
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs || tabs.length === 0) {
      domainTitle.textContent = 'No active tab';
      return;
    }

    currentTab = tabs[0];
    activeUrl = currentTab.url || '';

    // Ignore internal pages
    if (activeUrl.startsWith('chrome:') || activeUrl.startsWith('about:') || activeUrl.startsWith('edge:') || activeUrl.startsWith('moz-extension:')) {
      domainTitle.textContent = 'Internal browser page';
      noCookiesMessage.textContent = "AI4COLAB can't manage cookies on internal browser pages.";
      noCookiesMessage.classList.remove('hidden');
      addBtn.disabled = true;
      deleteAllBtn.disabled = true;
      importBtn.disabled = true;
      exportBtn.disabled = true;
      copyBtn.disabled = true;
      saveSessionBtn.disabled = true;
      newProfileNameInput.disabled = true;
      if (createCleanIsolatedBtn) createCleanIsolatedBtn.disabled = true;
      return;
    }

    try {
      const parsedUrl = new URL(activeUrl);
      activeDomain = parsedUrl.hostname;
      domainTitle.textContent = activeDomain;
      domainTitle.title = activeDomain;
    } catch (e) {
      domainTitle.textContent = 'Invalid URL';
      return;
    }

    // 0. Check Remote Kill Switch & Updates
    await checkRemoteConfigAndKillSwitch();

    // 2. Check if current tab is an Isolated Tab
    await checkTabIsolation();

    // 3. Set Sessions as the Default Active Tab on load
    switchTab('accounts');

    // 4. Load data
    loadProfiles();
    loadCookies();

    // 5. Set Event Listeners
    const openSidepanelBtn = document.getElementById('open-sidepanel-btn');
    if (openSidepanelBtn) {
      openSidepanelBtn.addEventListener('click', () => {
        if (chrome.sidePanel && chrome.sidePanel.open) {
          chrome.sidePanel.open({ windowId: currentTab.windowId }).then(() => {
            window.close();
          }).catch(() => {
            chrome.runtime.sendMessage({ type: 'OPEN_SIDE_PANEL', tabId: currentTab.id, windowId: currentTab.windowId }, () => {
              window.close();
            });
          });
        } else {
          chrome.runtime.sendMessage({ type: 'OPEN_SIDE_PANEL', tabId: currentTab.id, windowId: currentTab.windowId }, () => {
            window.close();
          });
        }
      });
    }

    const openDashboardBtn = document.getElementById('open-dashboard-btn');
    if (openDashboardBtn) {
      openDashboardBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
      });
    }

    if (detachIsolationBtn) {
      detachIsolationBtn.addEventListener('click', () => {
        if (confirm('Detach tab from cookie isolation? This tab will revert to standard shared cookies.')) {
          chrome.runtime.sendMessage({ type: 'END_TAB_ISOLATION', tabId: currentTab.id }, () => {
            chrome.tabs.reload(currentTab.id, {}, () => {
              window.close();
            });
          });
        }
      });
    }

    searchInput.addEventListener('input', filterCookies);
    addBtn.addEventListener('click', openAddForm);
    deleteAllBtn.addEventListener('click', deleteAllCookies);
    cancelBtn.addEventListener('click', closeForm);
    cookieSessionInput.addEventListener('change', toggleSessionInput);

    // JSON Event Listeners
    importBtn.addEventListener('click', openImportOverlay);
    exportBtn.addEventListener('click', exportCookiesJson);
    copyBtn.addEventListener('click', copyCookiesJson);
    importCancelBtn.addEventListener('click', closeImportOverlay);
    importSubmitBtn.addEventListener('click', submitImportCookies);

    // Tab Navigation (1st Sessions, 2nd Cookies)
    tabAccountsBtn.addEventListener('click', () => switchTab('accounts'));
    tabCookiesBtn.addEventListener('click', () => switchTab('cookies'));

    // Profile & Isolation Actions
    saveSessionBtn.addEventListener('click', saveCurrentSession);

    if (createCleanIsolatedBtn) {
      createCleanIsolatedBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({
          type: 'OPEN_ISOLATED_TAB',
          domain: activeDomain,
          url: activeUrl,
          profile: {
            name: `Clean Isolated (${activeDomain})`,
            cookies: []
          }
        }, (res) => {
          if (res && res.success) {
            window.close();
          }
        });
      });
    }

    // Auto-Save Toggle settings sync & trigger
    chrome.storage.local.get('auto_save_enabled', (result) => {
      if (popupAutosaveToggle) {
        popupAutosaveToggle.checked = !!result.auto_save_enabled;
      }
    });

    if (popupAutosaveToggle) {
      popupAutosaveToggle.addEventListener('change', () => {
        const isChecked = popupAutosaveToggle.checked;
        chrome.storage.local.set({ 'auto_save_enabled': isChecked }, () => {
          if (isChecked && activeDomain && !currentTabIsolation) {
            chrome.cookies.getAll({ domain: activeDomain }, (cookies) => {
              if (chrome.runtime.lastError || !cookies || cookies.length === 0) return;
              const validCookies = cookies.filter(c => c.name && c.value !== undefined);
              chrome.storage.local.get('sessions_by_domain', (resultStore) => {
                const store = resultStore.sessions_by_domain || {};
                let domainProfiles = store[activeDomain] || [];
                const autoIndex = domainProfiles.findIndex(p => p.id === 'profile-autosaved');
                const updatedProfile = {
                  id: 'profile-autosaved',
                  name: 'Auto-Saved Session',
                  savedAt: Date.now(),
                  cookies: validCookies
                };
                if (autoIndex !== -1) {
                  domainProfiles[autoIndex] = updatedProfile;
                } else {
                  domainProfiles.unshift(updatedProfile);
                }
                store[activeDomain] = domainProfiles;
                chrome.storage.local.set({ 'sessions_by_domain': store }, () => {
                  loadProfiles();
                });
              });
            });
          }
        });
      });
    }

    cookieForm.addEventListener('submit', saveCookie);
  }

  // Check Remote GitHub Config, Kill Switch & Available Updates
  async function checkRemoteConfigAndKillSwitch() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'GET_REMOTE_CONFIG_STATUS' }, (res) => {
        const state = (res && res.state) || {};
        const killswitchOverlay = document.getElementById('killswitch-overlay');
        const killswitchMessage = document.getElementById('killswitch-message');
        const killswitchRetryBtn = document.getElementById('killswitch-retry-btn');
        const updateBanner = document.getElementById('update-banner');
        const updateBannerTitle = document.getElementById('update-banner-title');
        const updateDownloadBtn = document.getElementById('update-download-btn');
        const updateDismissBtn = document.getElementById('update-dismiss-btn');

        // 1. Handle Kill Switch
        if (state.kill_switch_active || state.status === 'disabled') {
          if (killswitchOverlay) {
            killswitchOverlay.classList.remove('hidden');
            if (state.kill_switch_message && killswitchMessage) {
              killswitchMessage.textContent = state.kill_switch_message;
            }
          }
        } else {
          if (killswitchOverlay) killswitchOverlay.classList.add('hidden');
        }

        if (killswitchRetryBtn) {
          killswitchRetryBtn.onclick = () => {
            killswitchRetryBtn.disabled = true;
            killswitchRetryBtn.textContent = 'Checking...';
            chrome.runtime.sendMessage({ type: 'CHECK_REMOTE_CONFIG' }, () => {
              window.location.reload();
            });
          };
        }

        // 2. Handle Update Available
        if (state.update_available && !sessionStorage.getItem('ai4colab_update_dismissed')) {
          if (updateBanner) {
            updateBanner.classList.remove('hidden');
            if (updateBannerTitle) {
              updateBannerTitle.textContent = `🚀 Update Available: v${state.latest_version || 'Latest'}`;
            }
            if (updateDownloadBtn) {
              updateDownloadBtn.onclick = () => {
                const targetUrl = (state.config && state.config.update_url) || 'https://github.com/wwwrajdev/webcookies/releases';
                chrome.tabs.create({ url: targetUrl });
              };
            }
            if (updateDismissBtn) {
              updateDismissBtn.onclick = () => {
                updateBanner.classList.add('hidden');
                sessionStorage.setItem('ai4colab_update_dismissed', 'true');
              };
            }
          }
        }

        resolve();
      });
    });
  }

  // Check tab isolation status from background
  async function checkTabIsolation() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'GET_TAB_ISOLATION_INFO', tabId: currentTab.id }, (response) => {
        if (response && response.isIsolated && response.data) {
          currentTabIsolation = response.data;
          isolationBanner.classList.remove('hidden');
          isolationBannerProfile.textContent = `Profile: ${currentTabIsolation.profileName || 'Isolated Tab'}`;
          cookiesModeBadge.classList.remove('hidden');
          domainTitle.textContent = `${activeDomain} [ISOLATED]`;
        } else {
          currentTabIsolation = null;
          isolationBanner.classList.add('hidden');
          cookiesModeBadge.classList.add('hidden');
        }
        resolve();
      });
    });
  }

  // Tab switching logic (1st Sessions DEFAULT, 2nd Cookies)
  function switchTab(tabName) {
    if (tabName === 'cookies') {
      tabCookiesBtn.classList.add('active');
      tabAccountsBtn.classList.remove('active');
      panelCookies.classList.remove('hidden');
      panelAccounts.classList.add('hidden');
      footerActions.classList.remove('hidden');
      loadCookies();
    } else {
      tabAccountsBtn.classList.add('active');
      tabCookiesBtn.classList.remove('active');
      panelAccounts.classList.remove('hidden');
      panelCookies.classList.add('hidden');
      footerActions.classList.add('hidden');
      loadProfiles(); // Refresh profiles list when switching tabs
    }
  }

  // Load cookies (from Isolated Sandbox or standard chrome.cookies)
  async function loadCookies() {
    if (currentTabIsolation) {
      allCookies = (currentTabIsolation.cookies || []).sort((a, b) => a.name.localeCompare(b.name));
      renderCookies(allCookies);
    } else {
      // Query both URL and Domain to get comprehensive cookie list
      chrome.cookies.getAll({ url: activeUrl }, (urlCookies) => {
        chrome.cookies.getAll({ domain: activeDomain }, (domainCookies) => {
          const cookieMap = new Map();
          (domainCookies || []).forEach(c => cookieMap.set(`${c.name}_${c.domain}_${c.path}`, c));
          (urlCookies || []).forEach(c => cookieMap.set(`${c.name}_${c.domain}_${c.path}`, c));

          allCookies = Array.from(cookieMap.values()).sort((a, b) => a.name.localeCompare(b.name));
          renderCookies(allCookies);
        });
      });
    }
  }

  // Render cookies to list
  function renderCookies(cookiesToRender) {
    cookieList.innerHTML = '';

    if (cookiesToRender.length === 0) {
      noCookiesMessage.classList.remove('hidden');
      return;
    }

    noCookiesMessage.classList.add('hidden');

    cookiesToRender.forEach((cookie, index) => {
      const li = document.createElement('li');
      li.className = 'cookie-item';

      const isSession = cookie.session || !cookie.expirationDate;
      const secureLabel = cookie.secure ? `<span class="badge sec">Secure</span>` : '';
      const httpOnlyLabel = cookie.httpOnly ? `<span class="badge http">HttpOnly</span>` : '';

      li.innerHTML = `
        <div class="cookie-header" data-index="${index}">
          <div class="cookie-info">
            <span class="cookie-name" title="${escapeHtml(cookie.name)}">${escapeHtml(cookie.name)}</span>
            <span class="cookie-value-preview" title="${escapeHtml(cookie.value)}">${escapeHtml(cookie.value)}</span>
          </div>
          <div class="cookie-badges">
            ${httpOnlyLabel}
            ${secureLabel}
          </div>
        </div>
        <div class="cookie-details hidden" id="details-${index}">
          <div class="detail-row">
            <div class="detail-label">Value:</div>
            <div class="detail-value">${escapeHtml(cookie.value)}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">Domain:</div>
            <div class="detail-value">${escapeHtml(cookie.domain || activeDomain)}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">Path:</div>
            <div class="detail-value">${escapeHtml(cookie.path || '/')}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">Expiration:</div>
            <div class="detail-value">${isSession ? 'Session' : new Date(cookie.expirationDate * 1000).toLocaleString()}</div>
          </div>
          <div class="detail-row">
            <div class="detail-label">SameSite:</div>
            <div class="detail-value">${cookie.sameSite || 'unspecified'}</div>
          </div>
          <div class="cookie-actions">
            <button class="btn secondary edit-btn" data-index="${index}">Edit</button>
            <button class="btn danger delete-btn" data-index="${index}">Delete</button>
          </div>
        </div>
      `;

      // Expand/Collapse click event
      const header = li.querySelector('.cookie-header');
      header.addEventListener('click', () => {
        const details = li.querySelector('.cookie-details');
        const isHidden = details.classList.contains('hidden');

        document.querySelectorAll('.cookie-details').forEach(el => el.classList.add('hidden'));

        if (isHidden) {
          details.classList.remove('hidden');
        }
      });

      // Edit Button event
      li.querySelector('.edit-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        openEditForm(cookie);
      });

      // Delete Button event
      li.querySelector('.delete-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        deleteSingleCookie(cookie);
      });

      cookieList.appendChild(li);
    });
  }

  // Filter cookies on search input
  function filterCookies() {
    const query = searchInput.value.toLowerCase();
    const filtered = allCookies.filter(cookie =>
      cookie.name.toLowerCase().includes(query) ||
      cookie.value.toLowerCase().includes(query)
    );
    renderCookies(filtered);
  }

  // Helper to generate full cookie URL for APIs
  function getCookieUrl(cookie) {
    const domain = (cookie.domain || activeDomain).startsWith('.') ? (cookie.domain || activeDomain).substring(1) : (cookie.domain || activeDomain);
    return (cookie.secure ? 'https://' : 'http://') + domain + (cookie.path || '/');
  }

  // Open Form Overlay in "Add Mode"
  function openAddForm() {
    formTitle.textContent = 'Add New Cookie';
    cookieForm.reset();

    cookieDomainInput.value = activeDomain;
    cookiePathInput.value = '/';

    cookieSessionInput.checked = true;
    cookieExpirationInput.disabled = true;
    cookieNameInput.disabled = false;

    formOverlay.classList.remove('hidden');
  }

  // Open Form Overlay in "Edit Mode"
  function openEditForm(cookie) {
    formTitle.textContent = 'Edit Cookie';

    cookieNameInput.value = cookie.name;
    cookieNameInput.disabled = true;
    cookieValueInput.value = cookie.value;
    cookieDomainInput.value = cookie.domain || activeDomain;
    cookiePathInput.value = cookie.path || '/';

    cookieHttpOnlyInput.checked = !!cookie.httpOnly;
    cookieSecureInput.checked = !!cookie.secure;

    if (cookie.session || !cookie.expirationDate) {
      cookieSessionInput.checked = true;
      cookieExpirationInput.value = '';
      cookieExpirationInput.disabled = true;
    } else {
      cookieSessionInput.checked = false;
      cookieExpirationInput.disabled = false;

      const date = new Date(cookie.expirationDate * 1000);
      const tzoffset = date.getTimezoneOffset() * 60000;
      const localISOTime = (new Date(date - tzoffset)).toISOString().slice(0, 16);
      cookieExpirationInput.value = localISOTime;
    }

    cookieSameSiteInput.value = cookie.sameSite || 'unspecified';
    formOverlay.classList.remove('hidden');
  }

  function toggleSessionInput() {
    cookieExpirationInput.disabled = cookieSessionInput.checked;
    if (cookieSessionInput.checked) {
      cookieExpirationInput.value = '';
    }
  }

  function closeForm() {
    formOverlay.classList.add('hidden');
  }

  // Delete single cookie
  function deleteSingleCookie(cookie) {
    if (currentTabIsolation) {
      chrome.runtime.sendMessage({
        type: 'DELETE_ISOLATED_COOKIE',
        tabId: currentTab.id,
        cookieName: cookie.name
      }, () => {
        checkTabIsolation().then(loadCookies);
      });
    } else {
      const url = getCookieUrl(cookie);
      chrome.cookies.remove({
        name: cookie.name,
        url: url,
        storeId: cookie.storeId
      }, () => {
        loadCookies();
      });
    }
  }

  // Delete all cookies
  function deleteAllCookies() {
    if (allCookies.length === 0) return;

    const confirmDelete = confirm(`Are you sure you want to delete all ${allCookies.length} cookies for this site?`);
    if (!confirmDelete) return;

    if (currentTabIsolation) {
      chrome.runtime.sendMessage({
        type: 'CLEAR_ISOLATED_COOKIES',
        tabId: currentTab.id
      }, () => {
        checkTabIsolation().then(loadCookies);
      });
    } else {
      let deletedCount = 0;
      allCookies.forEach(cookie => {
        const url = getCookieUrl(cookie);
        chrome.cookies.remove({
          name: cookie.name,
          url: url,
          storeId: cookie.storeId
        }, () => {
          deletedCount++;
          if (deletedCount === allCookies.length) {
            loadCookies();
          }
        });
      });
    }
  }

  // Save (Create or Update) Cookie
  function saveCookie(e) {
    e.preventDefault();

    const name = cookieNameInput.value.trim();
    const value = cookieValueInput.value;
    const domain = cookieDomainInput.value.trim();
    const path = cookiePathInput.value.trim();
    const sameSite = cookieSameSiteInput.value;

    const cleanDomain = domain.startsWith('.') ? domain.substring(1) : domain;
    const url = (cookieSecureInput.checked ? 'https://' : 'http://') + cleanDomain + path;

    const cookieDetails = {
      url: url,
      name: name,
      value: value,
      domain: domain,
      path: path,
      secure: cookieSecureInput.checked,
      httpOnly: cookieHttpOnlyInput.checked
    };

    if (sameSite !== 'unspecified') {
      cookieDetails.sameSite = sameSite;
    }

    if (!cookieSessionInput.checked && cookieExpirationInput.value) {
      const expDate = new Date(cookieExpirationInput.value);
      cookieDetails.expirationDate = Math.floor(expDate.getTime() / 1000);
    }

    if (currentTabIsolation) {
      chrome.runtime.sendMessage({
        type: 'SET_ISOLATED_COOKIE',
        tabId: currentTab.id,
        cookie: cookieDetails
      }, () => {
        closeForm();
        checkTabIsolation().then(loadCookies);
      });
    } else {
      chrome.cookies.set(cookieDetails, (result) => {
        if (chrome.runtime.lastError) {
          alert('Error saving cookie: ' + chrome.runtime.lastError.message);
        } else {
          closeForm();
          loadCookies();
        }
      });
    }
  }

  // Open JSON Import Overlay
  function openImportOverlay() {
    importJsonData.value = '';
    importOverlay.classList.remove('hidden');
  }

  function closeImportOverlay() {
    importOverlay.classList.add('hidden');
  }

  // Export cookies JSON
  function exportCookiesJson() {
    if (allCookies.length === 0) {
      alert('No cookies to export.');
      return;
    }
    const cleanJson = allCookies.map(cookie => ({
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain || activeDomain,
      path: cookie.path || '/',
      secure: !!cookie.secure,
      httpOnly: !!cookie.httpOnly,
      expirationDate: cookie.expirationDate,
      sameSite: cookie.sameSite
    }));
    const jsonString = JSON.stringify(cleanJson, null, 2);
    const dataUrl = 'data:application/json;charset=utf-8,' + encodeURIComponent(jsonString);
    chrome.downloads.download({
      url: dataUrl,
      filename: `${activeDomain}_cookies.json`,
      saveAs: true
    });
  }

  // Copy cookies JSON
  function copyCookiesJson() {
    if (allCookies.length === 0) {
      alert('No cookies to copy.');
      return;
    }
    const cleanJson = allCookies.map(cookie => ({
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain || activeDomain,
      path: cookie.path || '/',
      secure: !!cookie.secure,
      httpOnly: !!cookie.httpOnly,
      expirationDate: cookie.expirationDate,
      sameSite: cookie.sameSite
    }));
    const jsonString = JSON.stringify(cleanJson, null, 2);

    navigator.clipboard.writeText(jsonString).then(() => {
      const originalText = copyBtn.innerText;
      copyBtn.innerText = 'Copied!';
      setTimeout(() => {
        copyBtn.innerText = originalText;
      }, 1500);
    }).catch(err => {
      alert('Failed to copy to clipboard: ' + err);
    });
  }

  // Import cookies JSON
  function submitImportCookies() {
    const rawVal = importJsonData.value.trim();
    if (!rawVal) {
      alert('Please paste some JSON data first.');
      return;
    }

    let parsed = null;
    try {
      parsed = JSON.parse(rawVal);
    } catch (e) {
      alert('Invalid JSON format: ' + e.message);
      return;
    }

    const cookiesArray = Array.isArray(parsed) ? parsed : [parsed];
    if (cookiesArray.length === 0) {
      alert('No cookies found in the array.');
      return;
    }

    if (currentTabIsolation) {
      cookiesArray.forEach(cookieData => {
        if (cookieData.name && cookieData.value !== undefined) {
          chrome.runtime.sendMessage({
            type: 'SET_ISOLATED_COOKIE',
            tabId: currentTab.id,
            cookie: {
              name: cookieData.name,
              value: String(cookieData.value),
              domain: cookieData.domain || activeDomain,
              path: cookieData.path || '/',
              secure: !!cookieData.secure,
              httpOnly: !!cookieData.httpOnly,
              expirationDate: cookieData.expirationDate,
              sameSite: cookieData.sameSite
            }
          });
        }
      });
      alert(`Imported ${cookiesArray.length} cookies into isolated tab.`);
      closeImportOverlay();
      checkTabIsolation().then(loadCookies);
    } else {
      let importCount = 0;
      let errorCount = 0;

      cookiesArray.forEach((cookieData) => {
        if (!cookieData.name || cookieData.value === undefined) {
          errorCount++;
          checkCompletion();
          return;
        }

        const domain = cookieData.domain || activeDomain;
        const path = cookieData.path || '/';
        const cleanDomain = domain.startsWith('.') ? domain.substring(1) : domain;
        const url = (cookieData.secure ? 'https://' : 'http://') + cleanDomain + path;

        const cookieObj = {
          url: url,
          name: cookieData.name,
          value: String(cookieData.value),
          domain: domain,
          path: path,
          secure: !!cookieData.secure,
          httpOnly: !!cookieData.httpOnly
        };

        if (cookieData.sameSite) cookieObj.sameSite = cookieData.sameSite;
        if (cookieData.expirationDate) cookieObj.expirationDate = cookieData.expirationDate;

        chrome.cookies.set(cookieObj, () => {
          if (chrome.runtime.lastError) {
            errorCount++;
          } else {
            importCount++;
          }
          checkCompletion();
        });
      });

      function checkCompletion() {
        if (importCount + errorCount === cookiesArray.length) {
          alert(`Successfully imported ${importCount} cookies. Errors: ${errorCount}.`);
          closeImportOverlay();
          loadCookies();
        }
      }
    }
  }

  // ==========================================
  // ACCOUNTS / SESSIONS PROFILES LOGIC
  // ==========================================

  // Load saved profiles from storage
  function loadProfiles() {
    chrome.storage.local.get('sessions_by_domain', (result) => {
      const store = result.sessions_by_domain || {};
      const domainProfiles = store[activeDomain] || [];

      const profilesList = document.getElementById('profiles-list');
      const noProfiles = document.getElementById('no-profiles');

      profilesList.innerHTML = '';

      if (domainProfiles.length === 0) {
        noProfiles.classList.remove('hidden');
        return;
      }

      noProfiles.classList.add('hidden');

      domainProfiles.forEach((profile) => {
        const li = document.createElement('li');
        li.className = 'profile-item';

        const isAutosaved = profile.id === 'profile-autosaved';
        const dateStr = new Date(profile.savedAt).toLocaleString();

        li.innerHTML = `
          <div class="profile-header" style="${isAutosaved ? 'background: rgba(52, 168, 83, 0.05); border-left: 2px solid var(--color-green);' : ''}">
            <div class="profile-info">
              <span class="profile-name" title="${escapeHtml(profile.name)}">
                ${escapeHtml(profile.name)}
                ${isAutosaved ? '<span style="font-size: 0.6rem; background-color: var(--color-green); color: white; padding: 2px 4px; border-radius: 4px; margin-left: 6px; font-weight: 700; vertical-align: middle;">AUTO</span>' : ''}
              </span>
              <span class="profile-details-preview">${(profile.cookies || []).length} cookies &bull; ${dateStr}</span>
            </div>
            <div class="profile-actions">
              <button class="btn success switch-btn">Switch</button>
              <button class="btn info open-isolated-btn" title="Open in new isolated tab with this profile's cookies">🚀 Isolated Tab</button>
              ${isAutosaved ? '' : '<button class="btn secondary update-btn" title="Overwrite profile with current page cookies">Update</button>'}
              <button class="btn danger delete-btn">Delete</button>
            </div>
          </div>
        `;

        li.querySelector('.switch-btn').addEventListener('click', () => {
          switchProfile(profile);
        });

        // Open in Isolated Tab handler with complete cookies payload
        li.querySelector('.open-isolated-btn').addEventListener('click', () => {
          chrome.runtime.sendMessage({
            type: 'OPEN_ISOLATED_TAB',
            domain: activeDomain,
            url: activeUrl,
            profile: profile
          }, (res) => {
            if (res && res.success) {
              window.close();
            }
          });
        });

        const updateBtn = li.querySelector('.update-btn');
        if (updateBtn) {
          updateBtn.addEventListener('click', () => {
            if (confirm(`Overwrite "${profile.name}" with your current session cookies?`)) {
              updateProfile(profile.id);
            }
          });
        }

        li.querySelector('.delete-btn').addEventListener('click', () => {
          if (confirm(`Delete profile "${profile.name}"?`)) {
            deleteProfile(profile.id);
          }
        });

        profilesList.appendChild(li);
      });
    });
  }

  // Save current cookies as a named session profile (captures URL + domain cookies)
  async function saveCurrentSession() {
    const profileName = newProfileNameInput.value.trim();
    if (!profileName) {
      alert('Please enter a profile name first.');
      return;
    }

    if (currentTabIsolation) {
      const cookies = currentTabIsolation.cookies || [];
      chrome.storage.local.get('sessions_by_domain', (result) => {
        const store = result.sessions_by_domain || {};
        const domainProfiles = store[activeDomain] || [];

        const newProfile = {
          id: 'profile-' + Date.now(),
          name: profileName,
          savedAt: Date.now(),
          cookies: cookies
        };

        domainProfiles.push(newProfile);
        store[activeDomain] = domainProfiles;

        chrome.storage.local.set({ 'sessions_by_domain': store }, () => {
          newProfileNameInput.value = '';
          loadProfiles();
          alert(`Successfully saved isolated session as profile: "${profileName}"`);
        });
      });
      return;
    }

    // Capture all cookies (both URL specific and Domain wildcard cookies)
    chrome.cookies.getAll({ url: activeUrl }, (urlCookies) => {
      chrome.cookies.getAll({ domain: activeDomain }, (domainCookies) => {
        const cookieMap = new Map();
        (domainCookies || []).forEach(c => cookieMap.set(`${c.name}_${c.domain}_${c.path}`, c));
        (urlCookies || []).forEach(c => cookieMap.set(`${c.name}_${c.domain}_${c.path}`, c));

        const fullCookies = Array.from(cookieMap.values()).filter(c => c && c.name && c.value !== undefined);

        if (fullCookies.length === 0) {
          alert('No cookies found on the current page to save.');
          return;
        }

        chrome.storage.local.get('sessions_by_domain', (result) => {
          const store = result.sessions_by_domain || {};
          const domainProfiles = store[activeDomain] || [];

          const newProfile = {
            id: 'profile-' + Date.now(),
            name: profileName,
            savedAt: Date.now(),
            cookies: fullCookies
          };

          domainProfiles.push(newProfile);
          store[activeDomain] = domainProfiles;

          chrome.storage.local.set({ 'sessions_by_domain': store }, () => {
            newProfileNameInput.value = '';
            loadProfiles();
            alert(`Successfully saved current session as profile: "${profileName}" (${fullCookies.length} cookies)`);
          });
        });
      });
    });
  }

  // Apply saved profile: delete existing and write saved cookies
  async function switchProfile(profile) {
    if (currentTabIsolation) {
      chrome.runtime.sendMessage({
        type: 'ISOLATE_EXISTING_TAB',
        tabId: currentTab.id,
        domain: activeDomain,
        profile: profile
      }, () => {
        window.close();
      });
      return;
    }

    chrome.cookies.getAll({ url: activeUrl }, async (currentCookies) => {
      const deletePromises = (currentCookies || []).map(cookie => {
        return new Promise((resolve) => {
          chrome.cookies.remove({
            name: cookie.name,
            url: getCookieUrl(cookie),
            storeId: cookie.storeId
          }, resolve);
        });
      });

      await Promise.all(deletePromises);

      const setPromises = (profile.cookies || []).map(cookieData => {
        return new Promise((resolve) => {
          const domain = cookieData.domain || activeDomain;
          const path = cookieData.path || '/';
          const cleanDomain = domain.startsWith('.') ? domain.substring(1) : domain;
          const url = (cookieData.secure ? 'https://' : 'http://') + cleanDomain + path;

          const newCookie = {
            url: url,
            name: cookieData.name,
            value: cookieData.value,
            domain: domain,
            path: path,
            secure: !!cookieData.secure,
            httpOnly: !!cookieData.httpOnly
          };

          if (cookieData.sameSite) newCookie.sameSite = cookieData.sameSite;
          if (cookieData.expirationDate) newCookie.expirationDate = cookieData.expirationDate;

          chrome.cookies.set(newCookie, resolve);
        });
      });

      await Promise.all(setPromises);

      chrome.tabs.reload(currentTab.id, {}, () => {
        window.close();
      });
    });
  }

  // Overwrite profile with active cookies
  function updateProfile(profileId) {
    const getCookiesAction = (cb) => {
      if (currentTabIsolation) {
        cb(currentTabIsolation.cookies || []);
      } else {
        chrome.cookies.getAll({ url: activeUrl }, (urlCookies) => {
          chrome.cookies.getAll({ domain: activeDomain }, (domainCookies) => {
            const cookieMap = new Map();
            (domainCookies || []).forEach(c => cookieMap.set(`${c.name}_${c.domain}_${c.path}`, c));
            (urlCookies || []).forEach(c => cookieMap.set(`${c.name}_${c.domain}_${c.path}`, c));
            cb(Array.from(cookieMap.values()));
          });
        });
      }
    };

    getCookiesAction((cookies) => {
      chrome.storage.local.get('sessions_by_domain', (result) => {
        const store = result.sessions_by_domain || {};
        const domainProfiles = store[activeDomain] || [];
        const index = domainProfiles.findIndex(p => p.id === profileId);

        if (index !== -1) {
          domainProfiles[index].cookies = cookies;
          domainProfiles[index].savedAt = Date.now();
          store[activeDomain] = domainProfiles;

          chrome.storage.local.set({ 'sessions_by_domain': store }, () => {
            alert(`Profile updated successfully with ${cookies.length} cookies!`);
            loadProfiles();
          });
        }
      });
    });
  }

  // Delete profile from storage
  function deleteProfile(profileId) {
    chrome.storage.local.get('sessions_by_domain', (result) => {
      const store = result.sessions_by_domain || {};
      let domainProfiles = store[activeDomain] || [];

      domainProfiles = domainProfiles.filter(p => p.id !== profileId);
      store[activeDomain] = domainProfiles;

      chrome.storage.local.set({ 'sessions_by_domain': store }, () => {
        loadProfiles();
      });
    });
  }

  // Drag and drop JSON file into popup to import cookies
  const dropIndicator = document.getElementById('drop-indicator');
  let dragCounter = 0;

  document.addEventListener('dragover', (e) => {
    e.preventDefault();
    if (dropIndicator) {
      dropIndicator.classList.remove('hidden');
    }
  });

  document.addEventListener('dragenter', (e) => {
    e.preventDefault();
    dragCounter++;
    if (dropIndicator) {
      dropIndicator.classList.remove('hidden');
    }
  });

  document.addEventListener('dragleave', (e) => {
    e.preventDefault();
    dragCounter--;
    if (dragCounter <= 0) {
      dragCounter = 0;
      if (dropIndicator) {
        dropIndicator.classList.add('hidden');
      }
    }
  });

  document.addEventListener('drop', (e) => {
    e.preventDefault();
    dragCounter = 0;
    if (dropIndicator) {
      dropIndicator.classList.add('hidden');
    }

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.name.endsWith('.json') || file.type === "application/json") {
        const reader = new FileReader();
        reader.onload = (event) => {
          const content = event.target.result;
          openImportOverlay();
          importJsonData.value = content;
        };
        reader.readAsText(file);
      } else {
        alert('Please drop a valid JSON file.');
      }
    }
  });

  function escapeHtml(str) {
    if (!str) return '';
    return str.toString()
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
});
