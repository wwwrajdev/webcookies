document.addEventListener('DOMContentLoaded', () => {
  let sessionsByDomain = {};
  let browserDomains = [];
  let activeCookieDomains = new Set();
  let activeIsolatedTabs = {};
  let activeDomain = '';
  let activeProfileId = '';
  let activeCookieIndex = -1; // -1 means adding new cookie

  // Sidebar Elements
  const navItems = document.querySelectorAll('.nav-item');
  const panels = document.querySelectorAll('.content-panel');

  // Overview Elements
  const statProfiles = document.getElementById('stat-profiles-count');
  const statDomains = document.getElementById('stat-domains-count');
  const statIsolated = document.getElementById('stat-isolated-count');
  const statCookies = document.getElementById('stat-cookies-count');
  const recentSessionsList = document.getElementById('recent-sessions-list');
  const quickManageBtn = document.getElementById('quick-manage-btn');
  const quickIsolatedBtn = document.getElementById('quick-isolated-btn');
  const quickExportBtn = document.getElementById('quick-export-btn');

  // Manage Panel Elements
  const domainSearchInput = document.getElementById('domain-search');
  const domainList = document.getElementById('domain-list');
  const selectedDomainTitle = document.getElementById('selected-domain-title');
  const selectedDomainCount = document.getElementById('selected-domain-count');
  const profilesContainer = document.getElementById('profiles-container');
  const noProfilesSelected = document.getElementById('no-profiles-selected');
  const profilesListWrapper = document.getElementById('profiles-list-wrapper');
  const profilesCardsGrid = document.getElementById('profiles-cards-grid');
  const addProfileCookieBtn = document.getElementById('add-profile-cookie-btn');
  const dashOpenCleanIsolatedBtn = document.getElementById('dash-open-clean-isolated-btn');

  // Isolated Tabs Panel Elements
  const isolatedCountLabel = document.getElementById('isolated-count-label');
  const refreshIsolatedTabsBtn = document.getElementById('refresh-isolated-tabs-btn');
  const noIsolatedTabs = document.getElementById('no-isolated-tabs');
  const isolatedTabsGrid = document.getElementById('isolated-tabs-grid');

  // Backup & Restore Elements
  const backupExportBtn = document.getElementById('backup-export-btn');
  const dropZone = document.getElementById('drop-zone');
  const importFileInput = document.getElementById('import-file-input');
  const backupImportJsonText = document.getElementById('backup-import-json');
  const backupImportMergeBtn = document.getElementById('backup-import-merge-btn');
  const backupImportOverwriteBtn = document.getElementById('backup-import-overwrite-btn');
  const backupClearAllBtn = document.getElementById('backup-clear-all-btn');

  // Modal 1: Rename Profile
  const modalRename = document.getElementById('modal-rename-profile');
  const renameInput = document.getElementById('rename-profile-input');
  const renameCancelBtn = document.getElementById('rename-cancel-btn');
  const renameSaveBtn = document.getElementById('rename-save-btn');

  // Modal 2: Cookie Manager inside Profile
  const modalCookieManager = document.getElementById('modal-cookie-manager');
  const cookieManagerTitle = document.getElementById('cookie-manager-title');
  const cookieManagerSubtitle = document.getElementById('cookie-manager-subtitle');
  const profileCookiesTbody = document.getElementById('profile-cookies-tbody');
  const addCookieToProfileBtn = document.getElementById('add-cookie-to-profile-btn');
  const cookieManagerCloseBtn = document.getElementById('cookie-manager-close-btn');
  const renameCloseX = document.getElementById('rename-close-x');
  const cookieManagerCloseX = document.getElementById('cookie-manager-close-x');

  // Modal 3: Add/Edit Cookie Form
  const modalCookieForm = document.getElementById('modal-cookie-form');
  const cookieFormTitle = document.getElementById('cookie-form-title');
  const dashboardCookieForm = document.getElementById('dashboard-cookie-form');
  const dashCookieName = document.getElementById('dash-cookie-name');
  const dashCookieValue = document.getElementById('dash-cookie-value');
  const dashCookieDomain = document.getElementById('dash-cookie-domain');
  const dashCookiePath = document.getElementById('dash-cookie-path');
  const dashCookieExpiration = document.getElementById('dash-cookie-expiration');
  const dashCookieSameSite = document.getElementById('dash-cookie-samesite');
  const dashCookieHttpOnly = document.getElementById('dash-cookie-httponly');
  const dashCookieSecure = document.getElementById('dash-cookie-secure');
  const dashCookieSession = document.getElementById('dash-cookie-session');
  const dashCookieCancelBtn = document.getElementById('dash-cookie-cancel-btn');
  const cookieFormCloseX = document.getElementById('cookie-form-close-x');
  const dashOverviewAutosaveToggle = document.getElementById('dash-overview-autosave-toggle');
  const dashProfilesAutosaveToggle = document.getElementById('dash-profiles-autosave-toggle');

  // Initialize Dashboard
  init();

  function init() {
    loadData(() => {
      renderStats();
      renderRecentSessions();
      renderDomainsList();
      renderIsolatedTabs();
    });

    // Panel Switching Listeners
    navItems.forEach(item => {
      item.addEventListener('click', () => {
        const panelId = item.getAttribute('data-panel');
        switchPanel(panelId);
      });
    });

    // Overview buttons
    quickManageBtn.addEventListener('click', () => switchPanel('manage'));
    if (quickIsolatedBtn) quickIsolatedBtn.addEventListener('click', () => switchPanel('isolated'));
    quickExportBtn.addEventListener('click', () => switchPanel('backup'));

    // Domain Search
    domainSearchInput.addEventListener('input', () => {
      renderDomainsList();
    });

    // Add Profile Button
    addProfileCookieBtn.addEventListener('click', () => {
      if (!activeDomain) return;
      const profileName = prompt(`Enter profile name for domain "${activeDomain}":`);
      if (profileName && profileName.trim()) {
        createNewProfile(profileName.trim(), []);
      }
    });

    // Clean Isolated Tab Button
    if (dashOpenCleanIsolatedBtn) {
      dashOpenCleanIsolatedBtn.addEventListener('click', () => {
        if (!activeDomain) return;
        chrome.runtime.sendMessage({
          type: 'OPEN_ISOLATED_TAB',
          domain: activeDomain,
          profile: {
            name: `Clean Sandbox (${activeDomain})`,
            cookies: []
          }
        }, (res) => {
          if (res && res.success) {
            alert(`Launched new clean isolated tab for ${activeDomain}!`);
            loadData(renderIsolatedTabs);
          }
        });
      });
    }

    // Refresh Isolated Tabs List
    if (refreshIsolatedTabsBtn) {
      refreshIsolatedTabsBtn.addEventListener('click', () => {
        loadData(renderIsolatedTabs);
      });
    }

    // Backup & Restore
    backupExportBtn.addEventListener('click', exportBackup);
    backupClearAllBtn.addEventListener('click', wipeAllData);
    backupImportMergeBtn.addEventListener('click', () => handleTextImport(true));
    backupImportOverwriteBtn.addEventListener('click', () => handleTextImport(false));

    // File drag & drop
    dropZone.addEventListener('click', () => importFileInput.click());
    importFileInput.addEventListener('change', handleFileSelect);
    setupDragAndDrop();

    // Modals events
    renameCancelBtn.addEventListener('click', () => closeModal(modalRename));
    if (renameCloseX) renameCloseX.addEventListener('click', () => closeModal(modalRename));
    renameSaveBtn.addEventListener('click', saveRenameProfile);

    cookieManagerCloseBtn.addEventListener('click', () => closeModal(modalCookieManager));
    if (cookieManagerCloseX) cookieManagerCloseX.addEventListener('click', () => closeModal(modalCookieManager));

    addCookieToProfileBtn.addEventListener('click', () => {
      openCookieFormModal(null, -1);
    });

    dashCookieCancelBtn.addEventListener('click', () => closeModal(modalCookieForm));
    if (cookieFormCloseX) cookieFormCloseX.addEventListener('click', () => closeModal(modalCookieForm));
    dashboardCookieForm.addEventListener('submit', handleCookieFormSubmit);
    dashCookieSession.addEventListener('change', toggleSessionCookieField);

    // Make modals draggable
    makeElementDraggable(modalRename);
    makeElementDraggable(modalCookieManager);
    makeElementDraggable(modalCookieForm);

    // Close modals on overlay backdrop click
    const overlays = [modalRename, modalCookieManager, modalCookieForm];
    overlays.forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          closeModal(overlay);
        }
      });
    });

    // Close dropdowns on document click
    document.addEventListener('click', () => {
      document.querySelectorAll('.profile-card-menu-dropdown').forEach(dropdown => {
        dropdown.classList.add('hidden');
      });
    });

    // Auto-Save Toggles
    chrome.storage.local.get('auto_save_enabled', (result) => {
      const isEnabled = !!result.auto_save_enabled;
      if (dashOverviewAutosaveToggle) dashOverviewAutosaveToggle.checked = isEnabled;
      if (dashProfilesAutosaveToggle) dashProfilesAutosaveToggle.checked = isEnabled;
    });

    function handleAutosaveChange(e) {
      const isChecked = e.target.checked;
      chrome.storage.local.set({ 'auto_save_enabled': isChecked }, () => {
        if (dashOverviewAutosaveToggle) dashOverviewAutosaveToggle.checked = isChecked;
        if (dashProfilesAutosaveToggle) dashProfilesAutosaveToggle.checked = isChecked;
      });
    }

    if (dashOverviewAutosaveToggle) dashOverviewAutosaveToggle.addEventListener('change', handleAutosaveChange);
    if (dashProfilesAutosaveToggle) dashProfilesAutosaveToggle.addEventListener('change', handleAutosaveChange);

    // Storage updates sync listener
    chrome.storage.onChanged.addListener((changes, namespace) => {
      if (namespace === 'local') {
        if (changes.auto_save_enabled) {
          const isEnabled = !!changes.auto_save_enabled.newValue;
          if (dashOverviewAutosaveToggle) dashOverviewAutosaveToggle.checked = isEnabled;
          if (dashProfilesAutosaveToggle) dashProfilesAutosaveToggle.checked = isEnabled;
        }
        if (changes.sessions_by_domain && activeDomain) {
          const newStore = changes.sessions_by_domain.newValue || {};
          const newProfiles = newStore[activeDomain] || [];
          chrome.cookies.getAll({ domain: activeDomain }, (liveCookies) => {
            renderProfilesCards(liveCookies || [], newProfiles);
          });
        }
        if (changes.isolated_tabs) {
          activeIsolatedTabs = changes.isolated_tabs.newValue || {};
          renderStats();
          renderIsolatedTabs();
        }
      }
    });
  }

  // Load storage data and active browser domains
  function loadData(callback) {
    chrome.storage.local.get(['sessions_by_domain', 'isolated_tabs'], (result) => {
      sessionsByDomain = result.sessions_by_domain || {};
      activeIsolatedTabs = result.isolated_tabs || {};

      chrome.cookies.getAll({}, (allCookies) => {
        const domainsSet = new Set();
        activeCookieDomains.clear();

        // Add domains from saved profiles
        Object.keys(sessionsByDomain).forEach(domain => {
          domainsSet.add(domain);
        });

        // Add domains with live cookies in browser
        (allCookies || []).forEach(cookie => {
          let d = cookie.domain;
          if (d.startsWith('.')) d = d.substring(1);

          if (!d.startsWith('chrome') && !d.includes('localhost') && !d.includes('127.0.0.1')) {
            domainsSet.add(d);
            activeCookieDomains.add(d);
          }
        });

        // Add domains from active isolated tabs
        Object.values(activeIsolatedTabs).forEach(iso => {
          if (iso.domain) domainsSet.add(iso.domain);
        });

        browserDomains = Array.from(domainsSet).sort();
        if (callback) callback();
      });
    });
  }

  // Save to storage
  function saveData(callback) {
    chrome.storage.local.set({ 'sessions_by_domain': sessionsByDomain }, () => {
      if (callback) callback();
    });
  }

  // Switch Active Panel
  function switchPanel(panelId) {
    navItems.forEach(item => {
      if (item.getAttribute('data-panel') === panelId) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    panels.forEach(panel => {
      if (panel.id === `panel-${panelId}`) {
        panel.classList.add('active');
      } else {
        panel.classList.remove('active');
      }
    });

    if (panelId === 'overview') {
      loadData(() => {
        renderStats();
        renderRecentSessions();
      });
    } else if (panelId === 'manage') {
      loadData(() => {
        renderDomainsList();
        if (activeDomain) {
          selectDomain(activeDomain);
        }
      });
    } else if (panelId === 'isolated') {
      loadData(() => {
        renderIsolatedTabs();
      });
    }
  }

  // Stats Logic
  function renderStats() {
    let totalProfilesCount = 0;
    let totalCookiesCount = 0;
    const domains = Object.keys(sessionsByDomain);

    domains.forEach(domain => {
      const profiles = sessionsByDomain[domain] || [];
      totalProfilesCount += profiles.length;
      profiles.forEach(p => {
        totalCookiesCount += (p.cookies || []).length;
      });
    });

    const isolatedCount = Object.keys(activeIsolatedTabs).length;

    statProfiles.textContent = totalProfilesCount;
    statDomains.textContent = domains.length;
    if (statIsolated) statIsolated.textContent = isolatedCount;
    statCookies.textContent = totalCookiesCount;
  }

  // Render recent sessions list
  function renderRecentSessions() {
    recentSessionsList.innerHTML = '';
    const allRecent = [];

    Object.keys(sessionsByDomain).forEach(domain => {
      const profiles = sessionsByDomain[domain] || [];
      profiles.forEach(profile => {
        allRecent.push({
          domain: domain,
          ...profile
        });
      });
    });

    allRecent.sort((a, b) => b.savedAt - a.savedAt);
    const topRecent = allRecent.slice(0, 5);

    if (topRecent.length === 0) {
      recentSessionsList.innerHTML = `<li class="info-message" style="padding:10px; font-size:0.8rem;">No recent session profiles.</li>`;
      return;
    }

    topRecent.forEach(item => {
      const li = document.createElement('li');
      li.className = 'recent-item';

      const dateStr = new Date(item.savedAt).toLocaleString();
      li.innerHTML = `
        <div>
          <strong>${escapeHtml(item.name)}</strong>
          <div style="font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(item.domain)} &bull; ${item.cookies.length} cookies</div>
        </div>
        <div style="display:flex; gap: 8px; align-items:center;">
          <span style="font-size: 0.7rem; color: var(--text-muted);">${dateStr}</span>
          <button class="btn secondary select-btn" style="padding: 4px 8px; font-size:0.75rem;">View</button>
        </div>
      `;

      li.querySelector('.select-btn').addEventListener('click', () => {
        activeDomain = item.domain;
        switchPanel('manage');
      });

      recentSessionsList.appendChild(li);
    });
  }

  // Render Domains Left List
  function renderDomainsList() {
    const filter = domainSearchInput.value.toLowerCase().trim();
    domainList.innerHTML = '';

    let hasDomains = false;

    browserDomains.forEach(domain => {
      if (filter && !domain.toLowerCase().includes(filter)) return;
      hasDomains = true;

      const profiles = sessionsByDomain[domain] || [];
      const hasActiveCookies = activeCookieDomains.has(domain);
      const hasIsolated = Object.values(activeIsolatedTabs).some(iso => iso.domain === domain);

      const li = document.createElement('li');
      li.className = 'domain-item';
      if (domain === activeDomain) {
        li.classList.add('active');
      }

      li.innerHTML = `
        <span class="domain-name" title="${escapeHtml(domain)}">${escapeHtml(domain)}</span>
        <div style="display: flex; gap: 4px; align-items: center;">
          ${hasIsolated ? '<span class="badge" style="background-color: rgba(168, 85, 247, 0.15); color: #a855f7; border: 1px solid rgba(168, 85, 247, 0.3); font-size: 0.65rem; padding: 2px 4px; border-radius: 4px; font-weight: 600;">ISOLATED</span>' : ''}
          ${hasActiveCookies ? '<span class="badge" style="background-color: rgba(66, 133, 244, 0.15); color: #4285F4; border: 1px solid rgba(66, 133, 244, 0.2); font-size: 0.65rem; padding: 2px 4px; border-radius: 4px; font-weight: 600;">ACTIVE</span>' : ''}
          ${profiles.length > 0 ? `<span class="badge badge-count">${profiles.length}</span>` : ''}
        </div>
      `;

      li.addEventListener('click', () => {
        document.querySelectorAll('.domain-item').forEach(el => el.classList.remove('active'));
        li.classList.add('active');
        selectDomain(domain);
      });

      domainList.appendChild(li);
    });

    if (!hasDomains) {
      domainList.innerHTML = `<li class="info-message" style="padding: 20px 10px; font-size:0.8rem;">No domains found.</li>`;
    }
  }

  // Select Domain Action
  function selectDomain(domain) {
    activeDomain = domain;
    selectedDomainTitle.textContent = domain;
    selectedDomainTitle.title = domain;

    noProfilesSelected.classList.add('hidden');
    profilesListWrapper.classList.remove('hidden');

    chrome.cookies.getAll({ domain: domain }, (liveCookies) => {
      const savedProfiles = sessionsByDomain[domain] || [];
      selectedDomainCount.textContent = `Active browser session + ${savedProfiles.length} profile${savedProfiles.length === 1 ? '' : 's'}`;

      renderProfilesCards(liveCookies || [], savedProfiles);
    });
  }

  // Render Profiles Cards inside pane-right
  function renderProfilesCards(liveCookies, savedProfiles) {
    profilesCardsGrid.innerHTML = '';

    // Active browser cookies card
    const activeProfile = {
      id: 'profile-active-browser',
      name: 'Active Browser Cookies',
      savedAt: Date.now(),
      cookies: liveCookies
    };
    renderSingleProfileCard(activeProfile, true);

    // Saved Profiles cards
    if (savedProfiles && savedProfiles.length > 0) {
      savedProfiles.forEach(profile => {
        renderSingleProfileCard(profile, false);
      });
    }
  }

  // Helper function to build a single profile card
  function renderSingleProfileCard(profile, isActiveSession) {
    const card = document.createElement('div');
    card.className = 'profile-card';
    const isAutosaved = profile.id === 'profile-autosaved';
    const dateStr = new Date(profile.savedAt).toLocaleString();

    let badgeHtml = '';
    let styleHeader = '';
    if (isActiveSession) {
      badgeHtml = '<span style="font-size: 0.6rem; background-color: var(--color-blue); color: white; padding: 2px 5px; border-radius: 4px; margin-left: 6px; font-weight: 700; vertical-align: middle;">LIVE</span>';
      styleHeader = 'border-left: 3px solid var(--color-blue); padding-left: 8px;';
    } else if (isAutosaved) {
      badgeHtml = '<span style="font-size: 0.6rem; background-color: var(--color-green); color: white; padding: 2px 5px; border-radius: 4px; margin-left: 6px; font-weight: 700; vertical-align: middle;">AUTO</span>';
      styleHeader = 'border-left: 3px solid var(--color-green); padding-left: 8px;';
    }

    card.innerHTML = `
      <div class="profile-card-header" style="${styleHeader}">
        <div class="profile-card-title-row">
          <span class="profile-card-title" title="${escapeHtml(profile.name)}">
            ${escapeHtml(profile.name)}
            ${badgeHtml}
          </span>
          <div class="profile-card-menu-container">
            <button class="menu-dot-btn" title="More Actions">⋮</button>
            <div class="profile-card-menu-dropdown hidden">
              ${(isActiveSession || isAutosaved) ? '' : '<button class="menu-item rename-btn">✏️ Rename</button>'}
              <button class="menu-item export-btn">📤 Export JSON</button>
              <button class="menu-item copy-json-btn">📋 Copy JSON</button>
              <div class="menu-divider"></div>
              ${isActiveSession
        ? '<button class="menu-item clear-active-btn danger">🧹 Clear Active</button>'
        : '<button class="menu-item delete-btn danger">🗑️ Delete</button>'}
            </div>
          </div>
        </div>
        <span class="profile-card-meta">${(profile.cookies || []).length} cookies &bull; ${isActiveSession ? 'Real-Time' : dateStr}</span>
      </div>
      <div class="profile-card-actions" style="display: flex; gap: 6px; margin-top: auto; flex-wrap: wrap;">
        ${isActiveSession
        ? `<button class="btn primary save-active-profile-btn" style="flex: 1; justify-content: center;" title="Save these active cookies as a session profile">Save Session</button>`
        : `<button class="btn success switch-profile-btn" style="flex: 1; justify-content: center; background-color: var(--color-green); color: #ffffff;" title="Switch active tab session to this profile">Switch Profile</button>
             <button class="btn info open-isolated-btn" style="flex: 1; justify-content: center;" title="Launch this profile in a new isolated cookie tab">🚀 Isolated Tab</button>`}
        <button class="btn secondary edit-cookies-btn" style="flex: 0.8; justify-content: center;" title="Edit individual cookies inside this profile">Edit Cookies</button>
      </div>
    `;

    // Handlers
    const dotBtn = card.querySelector('.menu-dot-btn');
    const dropdown = card.querySelector('.profile-card-menu-dropdown');

    dotBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      document.querySelectorAll('.profile-card-menu-dropdown').forEach(el => {
        if (el !== dropdown) el.classList.add('hidden');
      });
      dropdown.classList.toggle('hidden');
    });

    if (isActiveSession) {
      card.querySelector('.save-active-profile-btn').addEventListener('click', () => {
        const profileName = prompt("Enter a name for the new session profile:");
        if (profileName && profileName.trim()) {
          createNewProfile(profileName.trim(), profile.cookies);
        }
      });

      card.querySelector('.clear-active-btn').addEventListener('click', () => {
        dropdown.classList.add('hidden');
        if (confirm(`Clear all active browser cookies for "${activeDomain}"?`)) {
          chrome.cookies.getAll({ domain: activeDomain }, (cookies) => {
            const deletePromises = (cookies || []).map(c => {
              return new Promise(resolve => {
                chrome.cookies.remove({
                  name: c.name,
                  url: getCookieUrl(c),
                  storeId: c.storeId
                }, resolve);
              });
            });
            Promise.all(deletePromises).then(() => {
              alert(`Successfully cleared active browser cookies for ${activeDomain}`);
              selectDomain(activeDomain);
              loadData(() => {
                renderDomainsList();
              });
            });
          });
        }
      });
    } else {
      card.querySelector('.switch-profile-btn').addEventListener('click', () => {
        switchProfile(profile);
      });

      const openIsoBtn = card.querySelector('.open-isolated-btn');
      if (openIsoBtn) {
        openIsoBtn.addEventListener('click', () => {
          chrome.runtime.sendMessage({
            type: 'OPEN_ISOLATED_TAB',
            domain: activeDomain,
            profile: profile
          }, (res) => {
            if (res && res.success) {
              alert(`Launched new isolated tab for profile: "${profile.name}"`);
              loadData(() => {
                renderIsolatedTabs();
              });
            }
          });
        });
      }

      card.querySelector('.delete-btn').addEventListener('click', () => {
        dropdown.classList.add('hidden');
        if (confirm(`Are you sure you want to delete profile "${profile.name}"?`)) {
          deleteProfile(profile.id);
        }
      });
    }

    card.querySelector('.edit-cookies-btn').addEventListener('click', () => {
      openCookieManagerModal(profile.id);
    });

    const renameBtn = card.querySelector('.rename-btn');
    if (renameBtn) {
      renameBtn.addEventListener('click', () => {
        dropdown.classList.add('hidden');
        openRenameModal(profile.id, profile.name);
      });
    }

    card.querySelector('.export-btn').addEventListener('click', () => {
      dropdown.classList.add('hidden');
      exportSingleProfile(profile);
    });

    card.querySelector('.copy-json-btn').addEventListener('click', () => {
      dropdown.classList.add('hidden');
      navigator.clipboard.writeText(JSON.stringify(profile.cookies, null, 2)).then(() => {
        alert(`Copied "${profile.name}" cookies to clipboard!`);
      }).catch(err => {
        alert('Failed to copy to clipboard: ' + err.message);
      });
    });

    profilesCardsGrid.appendChild(card);
  }

  // -------------------------------------------------------------
  // ISOLATED TABS MONITOR PANEL LOGIC
  // -------------------------------------------------------------
  function renderIsolatedTabs() {
    const tabsList = Object.values(activeIsolatedTabs || {});
    isolatedCountLabel.textContent = `${tabsList.length} active isolated tab${tabsList.length === 1 ? '' : 's'}`;

    if (tabsList.length === 0) {
      noIsolatedTabs.classList.remove('hidden');
      isolatedTabsGrid.innerHTML = '';
      return;
    }

    noIsolatedTabs.classList.add('hidden');
    isolatedTabsGrid.innerHTML = '';

    tabsList.forEach((isoTab) => {
      const card = document.createElement('div');
      card.className = 'isolated-tab-card';
      const timeStr = new Date(isoTab.isolatedAt).toLocaleTimeString();

      card.innerHTML = `
        <div class="isolated-card-header">
          <div>
            <span class="badge" style="background-color: rgba(168, 85, 247, 0.2); color: #a855f7; border: 1px solid rgba(168, 85, 247, 0.4); font-size: 0.65rem;">TAB #${isoTab.tabId}</span>
            <strong style="margin-left: 6px; font-size: 0.95rem; color: #ffffff;">${escapeHtml(isoTab.profileName || 'Isolated Tab')}</strong>
          </div>
          <span style="font-size: 0.75rem; color: var(--text-muted);">${timeStr}</span>
        </div>
        <div class="isolated-card-body" style="padding: 10px 0; font-size: 0.8rem; color: var(--text-muted);">
          <div><strong>Domain:</strong> <span style="color: #4285F4;">${escapeHtml(isoTab.domain)}</span></div>
          <div><strong>Partitioned Cookies:</strong> ${(isoTab.cookies || []).length} items</div>
        </div>
        <div class="isolated-card-actions" style="display: flex; gap: 6px; flex-wrap: wrap;">
          <button class="btn primary focus-tab-btn" style="flex: 1; justify-content: center;">🔍 Focus Tab</button>
          <button class="btn secondary edit-iso-cookies-btn" style="flex: 1; justify-content: center;">✏️ Edit Cookies</button>
          <button class="btn danger close-iso-btn" style="flex: 0.8; justify-content: center;">✕ Close Tab</button>
        </div>
      `;

      card.querySelector('.focus-tab-btn').addEventListener('click', () => {
        chrome.tabs.get(isoTab.tabId, (tab) => {
          if (chrome.runtime.lastError || !tab) {
            alert('Tab has already been closed.');
            loadData(renderIsolatedTabs);
            return;
          }
          chrome.tabs.update(isoTab.tabId, { active: true });
          chrome.windows.update(tab.windowId, { focused: true });
        });
      });

      card.querySelector('.edit-iso-cookies-btn').addEventListener('click', () => {
        openIsolatedCookieManagerModal(isoTab);
      });

      card.querySelector('.close-iso-btn').addEventListener('click', () => {
        if (confirm(`Close isolated tab #${isoTab.tabId}?`)) {
          chrome.tabs.remove(isoTab.tabId, () => {
            loadData(renderIsolatedTabs);
          });
        }
      });

      isolatedTabsGrid.appendChild(card);
    });
  }

  // Cookie manager for isolated tab directly
  function openIsolatedCookieManagerModal(isoTab) {
    activeProfileId = `profile-isolated-${isoTab.tabId}`;
    activeDomain = isoTab.domain;

    cookieManagerTitle.textContent = `Isolated Cookies: Tab #${isoTab.tabId}`;
    cookieManagerSubtitle.textContent = `Profile: ${isoTab.profileName} | Domain: ${isoTab.domain}`;

    renderCookieTable(isoTab.cookies || []);
    openModal(modalCookieManager);
  }

  // Create New Profile
  function createNewProfile(name, cookies) {
    if (!sessionsByDomain[activeDomain]) {
      sessionsByDomain[activeDomain] = [];
    }

    const newProfile = {
      id: 'profile-' + Date.now(),
      name: name,
      savedAt: Date.now(),
      cookies: cookies
    };

    sessionsByDomain[activeDomain].push(newProfile);
    saveData(() => {
      selectDomain(activeDomain);
      renderDomainsList();
    });
  }

  // Delete Profile
  function deleteProfile(profileId) {
    if (!sessionsByDomain[activeDomain]) return;

    sessionsByDomain[activeDomain] = sessionsByDomain[activeDomain].filter(p => p.id !== profileId);

    if (sessionsByDomain[activeDomain].length === 0) {
      delete sessionsByDomain[activeDomain];
      activeDomain = '';
      noProfilesSelected.classList.remove('hidden');
      profilesListWrapper.classList.add('hidden');
    }

    saveData(() => {
      renderDomainsList();
      if (activeDomain) {
        selectDomain(activeDomain);
      }
    });
  }

  // Open Rename Modal
  function openRenameModal(profileId, currentName) {
    activeProfileId = profileId;
    renameInput.value = currentName;
    openModal(modalRename);
    renameInput.focus();
  }

  function saveRenameProfile() {
    const newName = renameInput.value.trim();
    if (!newName) {
      alert('Profile name cannot be empty.');
      return;
    }

    const profiles = sessionsByDomain[activeDomain] || [];
    const index = profiles.findIndex(p => p.id === activeProfileId);
    if (index !== -1) {
      profiles[index].name = newName;
      profiles[index].savedAt = Date.now();
      saveData(() => {
        closeModal(modalRename);
        selectDomain(activeDomain);
      });
    }
  }

  function openModal(modal) {
    modal.classList.remove('hidden');
    const content = modal.querySelector('.modal-content');
    if (content) {
      content.style.position = '';
      content.style.top = '';
      content.style.left = '';
      content.style.margin = '';
      content.style.transform = '';
    }
  }

  function closeModal(modal) {
    modal.classList.add('hidden');
  }

  function exportSingleProfile(profile) {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(profile, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `session_profile_${profile.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }

  // Cookie Manager Modal
  function openCookieManagerModal(profileId) {
    activeProfileId = profileId;
    if (profileId === 'profile-active-browser') {
      chrome.cookies.getAll({ domain: activeDomain }, (cookies) => {
        cookieManagerTitle.textContent = `Active Browser Cookies`;
        cookieManagerSubtitle.textContent = `Domain: ${activeDomain} | LIVE Real-Time Session`;

        renderCookieTable(cookies || []);
        openModal(modalCookieManager);
      });
    } else {
      const profile = (sessionsByDomain[activeDomain] || []).find(p => p.id === profileId);
      if (!profile) return;

      cookieManagerTitle.textContent = `Cookies inside "${profile.name}"`;
      cookieManagerSubtitle.textContent = `Domain: ${activeDomain} | Profile ID: ${profileId}`;

      renderCookieTable(profile.cookies);
      openModal(modalCookieManager);
    }
  }

  // Render Cookie Table Rows
  let activeModalCookies = [];
  function renderCookieTable(cookies) {
    activeModalCookies = cookies || [];
    profileCookiesTbody.innerHTML = '';

    if (activeModalCookies.length === 0) {
      profileCookiesTbody.innerHTML = `<tr><td colspan="7" class="info-message" style="text-align:center; padding: 20px;">No cookies saved inside this profile. Click "+ Add Cookie" to create one.</td></tr>`;
      return;
    }

    activeModalCookies.forEach((cookie, index) => {
      const tr = document.createElement('tr');
      const isSession = cookie.session || !cookie.expirationDate;
      const expDate = isSession ? 'Session' : new Date(cookie.expirationDate * 1000).toLocaleString();

      const secureBadge = cookie.secure ? `<span class="badge sec">Secure</span>` : '';
      const httpBadge = cookie.httpOnly ? `<span class="badge http">HttpOnly</span>` : '';

      tr.innerHTML = `
        <td title="${escapeHtml(cookie.name)}"><strong>${escapeHtml(cookie.name)}</strong></td>
        <td title="${escapeHtml(cookie.value)}">${escapeHtml(cookie.value)}</td>
        <td title="${escapeHtml(cookie.domain)}">${escapeHtml(cookie.domain)}</td>
        <td title="${escapeHtml(cookie.path)}">${escapeHtml(cookie.path)}</td>
        <td>${expDate}</td>
        <td>${httpBadge} ${secureBadge}</td>
        <td>
          <button class="btn success edit-btn" style="padding: 4px 8px; font-size: 0.7rem;">Edit</button>
          <button class="btn danger delete-btn" style="padding: 4px 8px; font-size: 0.7rem;">Delete</button>
        </td>
      `;

      tr.querySelector('.edit-btn').addEventListener('click', () => {
        openCookieFormModal(cookie, index);
      });

      tr.querySelector('.delete-btn').addEventListener('click', () => {
        if (confirm(`Remove cookie "${cookie.name}"?`)) {
          deleteCookieFromProfile(index);
        }
      });

      profileCookiesTbody.appendChild(tr);
    });
  }

  // Delete individual cookie from active profile / isolated tab
  function deleteCookieFromProfile(index) {
    if (activeProfileId.startsWith('profile-isolated-')) {
      const tabId = parseInt(activeProfileId.replace('profile-isolated-', ''), 10);
      const cookie = activeModalCookies[index];
      if (!cookie) return;

      chrome.runtime.sendMessage({
        type: 'DELETE_ISOLATED_COOKIE',
        tabId: tabId,
        cookieName: cookie.name
      }, () => {
        loadData(() => {
          if (activeIsolatedTabs[tabId]) {
            renderCookieTable(activeIsolatedTabs[tabId].cookies || []);
          }
          renderIsolatedTabs();
        });
      });
      return;
    }

    if (activeProfileId === 'profile-active-browser') {
      const cookie = activeModalCookies[index];
      if (!cookie) return;

      chrome.cookies.remove({
        name: cookie.name,
        url: getCookieUrl(cookie),
        storeId: cookie.storeId
      }, () => {
        chrome.cookies.getAll({ domain: activeDomain }, (updatedCookies) => {
          renderCookieTable(updatedCookies || []);
          loadData(() => {
            renderDomainsList();
          });
        });
      });
    } else {
      const profiles = sessionsByDomain[activeDomain] || [];
      const pIndex = profiles.findIndex(p => p.id === activeProfileId);
      if (pIndex !== -1) {
        profiles[pIndex].cookies.splice(index, 1);
        profiles[pIndex].savedAt = Date.now();
        saveData(() => {
          selectDomain(activeDomain);
          renderCookieTable(profiles[pIndex].cookies);
        });
      }
    }
  }

  // Cookie Form Modal opening
  function openCookieFormModal(cookie, index) {
    activeCookieIndex = index;

    if (cookie) {
      cookieFormTitle.textContent = `Edit Cookie: "${cookie.name}"`;
      dashCookieName.value = cookie.name;
      dashCookieName.disabled = true;

      dashCookieValue.value = cookie.value;
      dashCookieDomain.value = cookie.domain || activeDomain;
      dashCookiePath.value = cookie.path || '/';

      if (cookie.expirationDate) {
        const d = new Date(cookie.expirationDate * 1000);
        const offset = d.getTimezoneOffset() * 60000;
        const localISOTime = (new Date(d.getTime() - offset)).toISOString().slice(0, 16);
        dashCookieExpiration.value = localISOTime;
        dashCookieSession.checked = false;
        dashCookieExpiration.disabled = false;
      } else {
        dashCookieExpiration.value = '';
        dashCookieSession.checked = true;
        dashCookieExpiration.disabled = true;
      }

      dashCookieSameSite.value = cookie.sameSite || 'unspecified';
      dashCookieHttpOnly.checked = !!cookie.httpOnly;
      dashCookieSecure.checked = !!cookie.secure;
    } else {
      cookieFormTitle.textContent = 'Add New Cookie';
      dashCookieName.value = '';
      dashCookieName.disabled = false;
      dashCookieValue.value = '';
      dashCookieDomain.value = activeDomain;
      dashCookiePath.value = '/';
      dashCookieExpiration.value = '';
      dashCookieSession.checked = true;
      dashCookieExpiration.disabled = true;
      dashCookieSameSite.value = 'unspecified';
      dashCookieHttpOnly.checked = false;
      dashCookieSecure.checked = false;
    }

    openModal(modalCookieForm);
  }

  function toggleSessionCookieField() {
    if (dashCookieSession.checked) {
      dashCookieExpiration.value = '';
      dashCookieExpiration.disabled = true;
    } else {
      dashCookieExpiration.disabled = false;
    }
  }

  // Save/Create Cookie inside Profile / Isolated Tab
  function handleCookieFormSubmit(e) {
    e.preventDefault();

    const name = dashCookieName.value.trim();
    const value = dashCookieValue.value;
    const domain = dashCookieDomain.value.trim();
    const path = dashCookiePath.value.trim();
    const session = dashCookieSession.checked;
    const sameSite = dashCookieSameSite.value;
    const httpOnly = dashCookieHttpOnly.checked;
    const secure = dashCookieSecure.checked;

    let expirationDate = null;
    if (!session && dashCookieExpiration.value) {
      expirationDate = Math.floor(new Date(dashCookieExpiration.value).getTime() / 1000);
    }

    const cookieObj = {
      name: name,
      value: value,
      domain: domain,
      path: path,
      sameSite: sameSite,
      httpOnly: httpOnly,
      secure: secure,
      session: session
    };

    if (expirationDate) {
      cookieObj.expirationDate = expirationDate;
    }

    if (activeProfileId.startsWith('profile-isolated-')) {
      const tabId = parseInt(activeProfileId.replace('profile-isolated-', ''), 10);
      chrome.runtime.sendMessage({
        type: 'SET_ISOLATED_COOKIE',
        tabId: tabId,
        cookie: cookieObj
      }, () => {
        closeModal(modalCookieForm);
        loadData(() => {
          if (activeIsolatedTabs[tabId]) {
            renderCookieTable(activeIsolatedTabs[tabId].cookies || []);
          }
          renderIsolatedTabs();
        });
      });
      return;
    }

    if (activeProfileId === 'profile-active-browser') {
      const cleanDomain = domain.startsWith('.') ? domain.substring(1) : domain;
      const url = (secure ? 'https://' : 'http://') + cleanDomain + path;

      const setParam = {
        url: url,
        name: name,
        value: value,
        domain: domain,
        path: path,
        secure: secure,
        httpOnly: httpOnly
      };

      if (sameSite) setParam.sameSite = sameSite;
      if (!session && expirationDate) setParam.expirationDate = expirationDate;

      chrome.cookies.set(setParam, () => {
        if (chrome.runtime.lastError) {
          alert('Failed to save browser cookie: ' + chrome.runtime.lastError.message);
          return;
        }
        closeModal(modalCookieForm);
        chrome.cookies.getAll({ domain: activeDomain }, (updatedCookies) => {
          renderCookieTable(updatedCookies || []);
          loadData(() => {
            renderDomainsList();
          });
        });
      });
    } else {
      const profiles = sessionsByDomain[activeDomain] || [];
      const pIndex = profiles.findIndex(p => p.id === activeProfileId);
      if (pIndex !== -1) {
        if (activeCookieIndex === -1) {
          const exists = profiles[pIndex].cookies.some(c => c.name === name);
          if (exists) {
            alert(`A cookie with the name "${name}" already exists in this profile.`);
            return;
          }
          profiles[pIndex].cookies.push(cookieObj);
        } else {
          profiles[pIndex].cookies[activeCookieIndex] = cookieObj;
        }

        profiles[pIndex].savedAt = Date.now();
        saveData(() => {
          closeModal(modalCookieForm);
          renderCookieTable(profiles[pIndex].cookies);
          selectDomain(activeDomain);
        });
      }
    }
  }

  // Export full backup JSON
  function exportBackup() {
    const fullData = {
      sessions_by_domain: sessionsByDomain,
      exportedAt: Date.now(),
      app: 'AI4COLAB Session Switcher'
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(fullData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `ai4colab_sessions_backup_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }

  // Wipe storage
  function wipeAllData() {
    if (confirm("⚠️ WARNING: You are about to permanently delete ALL saved session profiles and cookies. This cannot be undone. Proceed?")) {
      sessionsByDomain = {};
      saveData(() => {
        activeDomain = '';
        noProfilesSelected.classList.remove('hidden');
        profilesListWrapper.classList.add('hidden');
        renderStats();
        renderRecentSessions();
        renderDomainsList();
        alert('All storage wiped successfully!');
      });
    }
  }

  // File selection
  function handleFileSelect(e) {
    const file = e.target.files[0];
    if (!file) return;
    readFileContent(file);
  }

  function readFileContent(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target.result;
      backupImportJsonText.value = content;
    };
    reader.readAsText(file);
  }

  function setupDragAndDrop() {
    ['dragenter', 'dragover'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
      }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
      }, false);
    });

    dropZone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      if (files.length > 0) {
        readFileContent(files[0]);
      }
    }, false);
  }

  function handleTextImport(isMerge) {
    const raw = backupImportJsonText.value.trim();
    if (!raw) {
      alert('Please paste JSON string or upload a JSON backup file first.');
      return;
    }

    try {
      const data = JSON.parse(raw);
      const incomingStore = data.sessions_by_domain || data;
      if (typeof incomingStore !== 'object') {
        alert('Invalid backup file structure: could not locate profiles database.');
        return;
      }

      let parsedSuccess = false;
      const domains = Object.keys(incomingStore);

      if (domains.length === 0) {
        alert('Imported JSON is empty.');
        return;
      }

      if (isMerge) {
        domains.forEach(domain => {
          if (!sessionsByDomain[domain]) {
            sessionsByDomain[domain] = [];
          }

          const incomingProfiles = incomingStore[domain] || [];
          incomingProfiles.forEach(incP => {
            const existingIndex = sessionsByDomain[domain].findIndex(p => p.id === incP.id || p.name === incP.name);
            if (existingIndex !== -1) {
              sessionsByDomain[domain][existingIndex] = incP;
            } else {
              sessionsByDomain[domain].push(incP);
            }
          });
        });
        parsedSuccess = true;
      } else {
        if (confirm('Overwrite active profiles? This will completely replace your current saved sessions.')) {
          sessionsByDomain = incomingStore;
          parsedSuccess = true;
        }
      }

      if (parsedSuccess) {
        saveData(() => {
          backupImportJsonText.value = '';
          alert('Sessions imported successfully!');
          renderStats();
          renderRecentSessions();
          renderDomainsList();
          if (activeDomain) {
            selectDomain(activeDomain);
          }
        });
      }

    } catch (e) {
      alert('Error parsing JSON backup file. Please check file format. Error: ' + e.message);
    }
  }

  // Make modal draggable
  function makeElementDraggable(modalOverlay) {
    const modalContent = modalOverlay.querySelector('.modal-content');
    if (!modalContent) return;

    const handle = modalContent.querySelector('.modal-header') || modalContent.querySelector('h3');
    if (!handle) return;

    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.style.cursor = 'move';
    handle.onmousedown = dragMouseDown;

    function dragMouseDown(e) {
      e = e || window.event;

      const targetTag = e.target.tagName.toLowerCase();
      if (['input', 'textarea', 'button', 'select', 'option', 'a'].includes(targetTag) ||
        e.target.closest('.btn') ||
        e.target.closest('.modal-actions') ||
        e.target.classList.contains('modal-close-x')) {
        return;
      }

      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;
      document.onmouseup = closeDragElement;
      document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
      e = e || window.event;
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;

      modalContent.style.position = 'absolute';
      modalContent.style.margin = '0';
      modalContent.style.transform = 'none';

      let newTop = modalContent.offsetTop - pos2;
      let newLeft = modalContent.offsetLeft - pos1;

      modalContent.style.top = newTop + "px";
      modalContent.style.left = newLeft + "px";
    }

    function closeDragElement() {
      document.onmouseup = null;
      document.onmousemove = null;
    }
  }

  // Switch Active Tab Session to Profile Cookies
  async function switchProfile(profile) {
    chrome.tabs.query({}, (tabs) => {
      const matchingTabs = tabs.filter(tab => {
        try {
          return new URL(tab.url).hostname === activeDomain;
        } catch (e) {
          return false;
        }
      });

      if (matchingTabs.length > 0) {
        const targetTab = matchingTabs[0];
        applyProfileCookiesToTab(profile, targetTab);
      } else {
        if (confirm(`No active tab found for "${activeDomain}". Open a new tab and switch session?`)) {
          const targetUrl = 'https://' + activeDomain;
          chrome.tabs.create({ url: targetUrl }, (newTab) => {
            applyProfileCookiesToTab(profile, newTab);
          });
        }
      }
    });
  }

  async function applyProfileCookiesToTab(profile, tab) {
    const url = tab.url || ('https://' + activeDomain);

    chrome.cookies.getAll({ url: url }, async (currentCookies) => {
      const deletePromises = (currentCookies || []).map(cookie => {
        return new Promise((resolve) => {
          chrome.cookies.remove({
            name: cookie.name,
            url: getCookieUrl(cookie),
            storeId: cookie.storeId
          }, resolve);
        });
      });

      await Promise.all(deletePromises);

      const setPromises = (profile.cookies || []).map(cookieData => {
        return new Promise((resolve) => {
          const domain = cookieData.domain || activeDomain;
          const path = cookieData.path || '/';
          const cleanDomain = domain.startsWith('.') ? domain.substring(1) : domain;
          const cookieUrl = (cookieData.secure ? 'https://' : 'http://') + cleanDomain + path;

          const newCookie = {
            url: cookieUrl,
            name: cookieData.name,
            value: cookieData.value,
            domain: domain,
            path: path,
            secure: !!cookieData.secure,
            httpOnly: !!cookieData.httpOnly
          };

          if (cookieData.sameSite) newCookie.sameSite = cookieData.sameSite;
          if (cookieData.expirationDate) newCookie.expirationDate = cookieData.expirationDate;

          chrome.cookies.set(newCookie, resolve);
        });
      });

      await Promise.all(setPromises);

      chrome.tabs.update(tab.id, { active: true }, () => {
        chrome.windows.update(tab.windowId, { focused: true }, () => {
          chrome.tabs.reload(tab.id);
        });
      });
    });
  }

  // -------------------------------------------------------------
  // Remote Config & Kill Switch Update Center Controller
  // -------------------------------------------------------------
  const statusInstalledVer = document.getElementById('status-installed-version');
  const statusLatestVer = document.getElementById('status-latest-version');
  const statusKillswitchBadge = document.getElementById('status-killswitch-badge');
  const remoteCheckTimestamp = document.getElementById('remote-check-timestamp');
  const inputRemoteConfigUrl = document.getElementById('input-remote-config-url');
  const btnForceCheckRemote = document.getElementById('btn-force-check-remote');
  const btnSaveRemoteUrl = document.getElementById('btn-save-remote-url');
  const btnResetRemoteUrl = document.getElementById('btn-reset-remote-url');
  const remoteJsonPreview = document.getElementById('remote-json-preview');

  function initUpdatesPanel() {
    refreshRemoteConfigStatus();

    if (btnForceCheckRemote) {
      btnForceCheckRemote.addEventListener('click', () => {
        btnForceCheckRemote.disabled = true;
        btnForceCheckRemote.textContent = '🔄 Checking...';
        chrome.runtime.sendMessage({ type: 'CHECK_REMOTE_CONFIG' }, () => {
          btnForceCheckRemote.disabled = false;
          btnForceCheckRemote.textContent = '🔄 Check Remote Config Now';
          refreshRemoteConfigStatus();
        });
      });
    }

    if (btnSaveRemoteUrl) {
      btnSaveRemoteUrl.addEventListener('click', () => {
        const url = inputRemoteConfigUrl ? inputRemoteConfigUrl.value.trim() : '';
        if (!url) {
          alert('Please enter a valid GitHub raw JSON URL.');
          return;
        }
        btnSaveRemoteUrl.disabled = true;
        chrome.runtime.sendMessage({ type: 'SET_REMOTE_CONFIG_URL', url: url }, () => {
          btnSaveRemoteUrl.disabled = false;
          alert('Remote GitHub Config URL updated and synced successfully!');
          refreshRemoteConfigStatus();
        });
      });
    }

    if (btnResetRemoteUrl) {
      btnResetRemoteUrl.addEventListener('click', () => {
        const defaultUrl = 'https://raw.githubusercontent.com/wwwrajdev/webcookies/main/config.json';
        if (inputRemoteConfigUrl) inputRemoteConfigUrl.value = defaultUrl;
        chrome.runtime.sendMessage({ type: 'SET_REMOTE_CONFIG_URL', url: defaultUrl }, () => {
          alert('Reset to default official AI4COLAB GitHub config URL.');
          refreshRemoteConfigStatus();
        });
      });
    }
  }

  function refreshRemoteConfigStatus() {
    chrome.runtime.sendMessage({ type: 'GET_REMOTE_CONFIG_STATUS' }, (res) => {
      const state = (res && res.state) || {};
      const currentVer = (res && res.current_version) || '27.8.2026.8.15';

      if (statusInstalledVer) statusInstalledVer.textContent = currentVer;

      if (statusLatestVer) {
        statusLatestVer.textContent = state.latest_version ? `v${state.latest_version}` : 'Checking...';
        if (state.update_available) {
          statusLatestVer.style.color = 'var(--color-yellow)';
          statusLatestVer.textContent += ' (UPDATE AVAILABLE)';
        } else {
          statusLatestVer.style.color = 'var(--color-green)';
        }
      }

      if (statusKillswitchBadge) {
        if (state.kill_switch_active || state.status === 'disabled') {
          statusKillswitchBadge.textContent = '🔴 KILL SWITCH ACTIVE';
          statusKillswitchBadge.style.color = 'var(--color-red)';
        } else {
          statusKillswitchBadge.textContent = '🟢 OPERATIONAL';
          statusKillswitchBadge.style.color = 'var(--color-green)';
        }
      }

      if (remoteCheckTimestamp && state.last_checked_at) {
        remoteCheckTimestamp.textContent = `Last checked: ${new Date(state.last_checked_at).toLocaleTimeString()}`;
      }

      if (inputRemoteConfigUrl && state.url) {
        inputRemoteConfigUrl.value = state.url;
      }

      if (remoteJsonPreview) {
        remoteJsonPreview.textContent = JSON.stringify(state.config || state, null, 2);
      }
    });
  }

  initUpdatesPanel();

  function getCookieUrl(cookie) {
    return (cookie.secure ? 'https://' : 'http://') +
      (cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain) +
      cookie.path;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str.toString()
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
});

